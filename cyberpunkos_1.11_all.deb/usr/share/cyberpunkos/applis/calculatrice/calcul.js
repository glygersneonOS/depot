.pragma library
// =====================================================================
//  calcul.js — moteur de la Calculatrice CyberpunkOS
//  (calculs SANS eval : on lit le calcul nous-mêmes, rien d'autre ne peut s'exécuter)
//
//  evaluer(texte, radians)  → nombre (ou erreur)
//  formater(nombre)         → texte à la française : 15 000 · 3,14 · 1,5e+16
//  afficher(saisie)         → la saisie avec les espaces des milliers
//  saisir(etat, touche)     → nouvel état après l'appui sur une touche
//  apercu(saisie, radians)  → résultat provisoire (ou "")
//  CONVERSIONS / convertir(categorie, valeur, de, vers)
// =====================================================================

var ESPACE = " "          // espace fine des milliers
var OPS = "+−×÷^"
var FONCTIONS = ["asin", "acos", "atan", "sin", "cos", "tan", "ln", "log", "√"]

// ---------- lecture du calcul ----------
function decouper(texte) {
    var s = String(texte).replace(/[\s  ]/g, "")
    var t = [], i = 0
    while (i < s.length) {
        var c = s.charAt(i)
        if (/[0-9.,]/.test(c)) {
            var j = i
            while (j < s.length && /[0-9.,]/.test(s.charAt(j))) j++
            var n = s.substring(i, j).replace(/,/g, ".")
            if (n === "." || (n.match(/\./g) || []).length > 1) throw new Error("nombre mal écrit")
            // notation scientifique d'un résultat recopié : 1,5e+16
            var m = /^e([+\-−]?)(\d+)/.exec(s.substring(j))
            if (m) {
                n += "e" + (m[1] === "+" || m[1] === "" ? "+" : "-") + m[2]
                j += m[0].length
            }
            t.push({ t: "n", v: parseFloat(n) })
            i = j
            continue
        }
        if (c === "+") { t.push({ t: "op", v: "+" }); i++; continue }
        if (c === "-" || c === "−") { t.push({ t: "op", v: "-" }); i++; continue }
        if (c === "*" || c === "×") { t.push({ t: "op", v: "*" }); i++; continue }
        if (c === "/" || c === "÷") { t.push({ t: "op", v: "/" }); i++; continue }
        if (c === "^") { t.push({ t: "op", v: "^" }); i++; continue }
        if (c === "(" || c === ")") { t.push({ t: c }); i++; continue }
        if (c === "!" || c === "%") { t.push({ t: c }); i++; continue }
        if (c === "π") { t.push({ t: "c", v: Math.PI }); i++; continue }
        var trouve = false
        for (var k = 0; k < FONCTIONS.length; k++) {
            var f = FONCTIONS[k]
            if (s.substring(i, i + f.length) === f) {
                t.push({ t: "f", v: f }); i += f.length; trouve = true; break
            }
        }
        if (trouve) continue
        if (s.substring(i, i + 2) === "pi") { t.push({ t: "c", v: Math.PI }); i += 2; continue }
        if (c === "e") { t.push({ t: "c", v: Math.E }); i++; continue }
        throw new Error("caractère inconnu : " + c)
    }
    return t
}

function propre(x) {                       // efface les poussières de calcul (sin 180° = 0)
    return Math.abs(x) < 1e-13 ? 0 : x
}

function factorielle(x) {
    if (x < 0 || x !== Math.floor(x)) throw new Error("factorielle d'un entier positif seulement")
    if (x > 170) throw new Error("nombre trop grand")
    var r = 1
    for (var i = 2; i <= x; i++) r *= i
    return r
}

function appliquer(f, x, radians) {
    var a = radians ? x : x * Math.PI / 180
    switch (f) {
    case "sin": return propre(Math.sin(a))
    case "cos": return propre(Math.cos(a))
    case "tan":
        if (!radians && Math.abs(((x % 180) + 180) % 180 - 90) < 1e-12) throw new Error("tan n'existe pas ici")
        return propre(Math.tan(a))
    case "asin": case "acos":
        if (x < -1 || x > 1) throw new Error("hors limites")
        var r = f === "asin" ? Math.asin(x) : Math.acos(x)
        return radians ? r : r * 180 / Math.PI
    case "atan":
        var t = Math.atan(x)
        return radians ? t : t * 180 / Math.PI
    case "ln":
        if (x <= 0) throw new Error("ln d'un nombre positif seulement")
        return Math.log(x)
    case "log":
        if (x <= 0) throw new Error("log d'un nombre positif seulement")
        return Math.log(x) / Math.LN10
    case "√":
        if (x < 0) throw new Error("racine d'un nombre négatif")
        return Math.sqrt(x)
    }
    throw new Error("fonction inconnue")
}

function evaluer(texte, radians) {
    var tk = decouper(texte)
    if (tk.length === 0) throw new Error("vide")
    // parenthèses oubliées : on les ferme
    var ouv = 0
    for (var i = 0; i < tk.length; i++) {
        if (tk[i].t === "(") ouv++
        else if (tk[i].t === ")") ouv--
        if (ouv < 0) throw new Error("parenthèse en trop")
    }
    while (ouv-- > 0) tk.push({ t: ")" })

    var p = 0
    function voir() { return tk[p] }
    function estOp(v) { var x = voir(); return x && x.t === "op" && x.v === v }

    function expression() {
        var g = terme()
        while (estOp("+") || estOp("-")) {
            var o = tk[p++].v
            var d = terme()
            var dv = d.pct ? g.v * d.v : d.v      // 200 + 10 % = 220
            g = { v: o === "+" ? g.v + dv : g.v - dv }
        }
        return g
    }
    function terme() {
        var g = unaire()
        while (true) {
            if (estOp("*") || estOp("/")) {
                var o = tk[p++].v
                var d = unaire()
                if (o === "/" && d.v === 0) throw new Error("division par zéro")
                g = { v: o === "*" ? g.v * d.v : g.v / d.v }
            } else if (voir() && (voir().t === "(" || voir().t === "f" || voir().t === "c")) {
                var d2 = unaire()                 // 2π, 3(4+1), 2√9 → multiplication
                g = { v: g.v * d2.v }
            } else break
        }
        return g
    }
    function unaire() {
        if (estOp("-")) { p++; var x = unaire(); return { v: -x.v, pct: x.pct } }
        if (estOp("+")) { p++; return unaire() }
        return puissance()
    }
    function puissance() {
        var b = postfixe()
        if (estOp("^")) {
            p++
            var e = unaire()
            var r = Math.pow(b.v, e.v)
            if (isNaN(r)) throw new Error("puissance impossible")
            return { v: r }
        }
        return b
    }
    function postfixe() {
        var x = primaire()
        while (voir() && (voir().t === "!" || voir().t === "%")) {
            var s = tk[p++].t
            x = s === "!" ? { v: factorielle(x.v) } : { v: x.v / 100, pct: true }
        }
        return x
    }
    function primaire() {
        var a = tk[p++]
        if (!a) throw new Error("calcul incomplet")
        if (a.t === "n" || a.t === "c") return { v: a.v }
        if (a.t === "(") {
            var x = expression()
            if (!voir() || voir().t !== ")") throw new Error("parenthèse manquante")
            p++
            return { v: x.v }
        }
        if (a.t === "f") {
            var arg = postfixe()
            return { v: appliquer(a.v, arg.v, radians) }
        }
        throw new Error("calcul incomplet")
    }

    var res = expression()
    if (p < tk.length) throw new Error("calcul mal écrit")
    if (!isFinite(res.v)) throw new Error("résultat trop grand")
    return res.v
}

// ---------- écriture des nombres ----------
function grouper(entier) {
    return entier.replace(/\B(?=(\d{3})+(?!\d))/g, ESPACE)
}

function formater(n) {
    if (typeof n !== "number" || !isFinite(n)) return "Erreur"
    n = parseFloat(n.toPrecision(12))      // 0,1 + 0,2 = 0,3 (et pas 0,30000000000000004)
    if (n === 0) return "0"
    var neg = n < 0, a = Math.abs(n), s
    if (a >= 1e15 || a < 1e-9) {
        s = a.toExponential(9).replace(/\.?0+e/, "e").replace(".", ",").replace("e-", "e−")
    } else {
        var dec = Math.min(20, Math.max(0, 11 - Math.floor(Math.log(a) / Math.LN10)))
        s = a.toFixed(dec)
        if (s.indexOf(".") >= 0) s = s.replace(/0+$/, "").replace(/\.$/, "")
        var parts = s.split(".")
        s = grouper(parts[0]) + (parts.length > 1 ? "," + parts[1] : "")
    }
    return (neg ? "−" : "") + s
}

function afficher(saisie) {                  // ajoute les espaces des milliers pendant la frappe
    var s = String(saisie).replace(/[ \s]/g, "")
    return s.replace(/\d+(,\d*)?/g, function (m) {
        var i = m.indexOf(",")
        return i < 0 ? grouper(m) : grouper(m.substring(0, i)) + m.substring(i)
    })
}

// ---------- saisie touche par touche ----------
function dernier(s) { return s.length ? s.charAt(s.length - 1) : "" }
function finitParValeur(s) { var c = dernier(s); return /[0-9)π!%e]/.test(c) }
function compte(s, c) { return s.split(c).length - 1 }

function apercu(saisie, radians) {
    var s = String(saisie)
    if (!/[+−×÷^%!√(a-zπ]/.test(s.replace(/^−/, ""))) return ""
    try { return formater(evaluer(s, radians)) } catch (e) { return "" }
}

// etat = { saisie, fini, resultat, calcul, erreur }
function saisir(etat, touche, radians) {
    var s = etat.fini ? "" : etat.saisie
    var base = etat.fini ? etat.resultat.replace(/ /g, "") : ""
    var r = { saisie: etat.saisie, fini: false, resultat: etat.resultat, calcul: etat.fini ? etat.calcul : "", erreur: "" }

    if (touche === "C") return { saisie: "", fini: false, resultat: "", calcul: "", erreur: "" }

    if (touche === "⌫") {
        if (etat.fini) { r.saisie = ""; r.calcul = ""; return r }
        var m = /(asin|acos|atan|sin|cos|tan|ln|log|√)\($/.exec(s)
        r.saisie = m ? s.substring(0, s.length - m[0].length) : s.substring(0, s.length - 1)
        return r
    }

    if (touche === "=") {
        if (etat.fini || !etat.saisie) return etat
        try {
            var v = evaluer(etat.saisie, radians)
            var f = formater(v)
            return { saisie: f.replace(/ /g, ""), fini: true, resultat: f, calcul: afficher(etat.saisie) + " =", erreur: "", valeur: v }
        } catch (e) {
            r.saisie = etat.saisie; r.erreur = e.message; return r
        }
    }

    if (touche === "±") {
        if (etat.fini) { r.saisie = base.charAt(0) === "−" ? base.substring(1) : "−" + base; return r }
        var n = /(\(−)?([0-9,]+)$/.exec(s)
        if (!n) { if (s === "") r.saisie = "(−"; return r }
        r.saisie = s.substring(0, s.length - n[0].length) + (n[1] ? n[2] : "(−" + n[2])
        return r
    }

    // opérateurs et touches « après une valeur »
    var apresValeur = { "x²": "^2", "1/x": "^(−1)", "%": "%", "!": "!" }
    if (OPS.indexOf(touche) >= 0 || apresValeur[touche] !== undefined) {
        var ajout = apresValeur[touche] !== undefined ? apresValeur[touche] : touche
        if (etat.fini) { r.saisie = base + ajout; return r }
        var d = dernier(s)
        if (apresValeur[touche] !== undefined) {
            if (finitParValeur(s)) r.saisie = s + ajout
            else r.saisie = s
            return r
        }
        if (s === "" || d === "(") { r.saisie = touche === "−" ? s + "−" : s; return r }
        if (OPS.indexOf(d) >= 0) {
            if (touche === "−" && "×÷^".indexOf(d) >= 0) { r.saisie = s + "−"; return r }   // 5 × −3
            var s2 = s.substring(0, s.length - 1)
            if (OPS.indexOf(dernier(s2)) >= 0) s2 = s2.substring(0, s2.length - 1)
            r.saisie = s2 === "" ? (touche === "−" ? "−" : "") : s2 + touche
            return r
        }
        r.saisie = s + touche
        return r
    }

    if (touche === ")") {
        if (compte(s, "(") > compte(s, ")") && finitParValeur(s)) r.saisie = s + ")"
        else r.saisie = s
        return r
    }

    if (touche === ",") {
        var num = /[0-9,]*$/.exec(s)[0]
        if (num.indexOf(",") >= 0) { r.saisie = s; return r }
        r.saisie = (num === "" ? s + (finitParValeur(s) ? "×" : "") + "0," : s + ",")
        return r
    }

    if (/^[0-9]$/.test(touche)) {
        var c = dernier(s)
        r.saisie = s + (/[)π!%e]/.test(c) ? "×" : "") + touche
        return r
    }

    // π, e, fonctions « sin( », parenthèse ouvrante : multiplication implicite gérée par le moteur
    r.saisie = s + touche
    return r
}

// ---------- conversions ----------
var CONVERSIONS = [
    { nom: "Longueur", unites: [["mm", 0.001], ["cm", 0.01], ["m", 1], ["km", 1000], ["pouce", 0.0254], ["pied", 0.3048], ["mile", 1609.344]] },
    { nom: "Masse", unites: [["mg", 1e-6], ["g", 0.001], ["kg", 1], ["tonne", 1000], ["livre", 0.45359237], ["once", 0.028349523125]] },
    { nom: "Température", unites: [["°C", 0], ["°F", 0], ["K", 0]], temperature: true },
    { nom: "Volume", unites: [["mL", 0.001], ["cL", 0.01], ["L", 1], ["m³", 1000], ["gallon US", 3.785411784]] },
    { nom: "Vitesse", unites: [["m/s", 1], ["km/h", 1 / 3.6], ["mph", 0.44704], ["nœud", 1852 / 3600]] },
    { nom: "Données", unites: [["octet", 1], ["Ko", 1024], ["Mo", 1048576], ["Go", 1073741824], ["To", 1099511627776]] },
    { nom: "Temps", unites: [["seconde", 1], ["minute", 60], ["heure", 3600], ["jour", 86400], ["semaine", 604800]] }
]

function convertir(categorie, valeur, de, vers) {
    var c = CONVERSIONS[categorie]
    if (c.temperature) {
        var celsius = de === 0 ? valeur : de === 1 ? (valeur - 32) * 5 / 9 : valeur - 273.15
        return vers === 0 ? celsius : vers === 1 ? celsius * 9 / 5 + 32 : celsius + 273.15
    }
    return valeur * c.unites[de][1] / c.unites[vers][1]
}

// saisie simple pour la conversion (chiffres, virgule, ±, ⌫, C)
function saisirNombre(s, touche) {
    if (touche === "C") return "0"
    if (touche === "⌫") { var t = s.substring(0, s.length - 1); return t === "" || t === "−" ? "0" : t }
    if (touche === "±") return s === "0" ? s : (s.charAt(0) === "−" ? s.substring(1) : "−" + s)
    if (touche === ",") return s.indexOf(",") >= 0 ? s : s + ","
    if (/^[0-9]$/.test(touche)) {
        if (s.replace(/[−,]/g, "").length >= 15) return s
        return s === "0" ? touche : (s === "−0" ? "−" + touche : s + touche)
    }
    return s
}

function nombre(s) {
    return parseFloat(String(s).replace(/[ \s]/g, "").replace("−", "-").replace(",", ".")) || 0
}
