// =====================================================================
//  Calculatrice CyberpunkOS (croquis validé le 11/11/2026)
//  Standard · Scientifique · Conversion — historique — clavier et pavé numérique
//  Lancée par cyberpunkos-calculatrice :  qml Calculatrice.qml -- <fichier de mémoire>
//  Le calcul est fait par calcul.js (sans eval).
// =====================================================================
import QtQuick
import QtQuick.Window
import "calcul.js" as Calc

Window {
    id: win
    visible: true
    width: 420; height: 700
    minimumWidth: 380; minimumHeight: 620
    color: nuit
    title: "Calculatrice"

    // ---- couleurs CyberpunkOS
    readonly property color jaune: "#f5e400"
    readonly property color cyan: "#00f0ff"
    readonly property color magenta: "#ff2bd6"
    readonly property color nuit: "#07080f"
    readonly property color panneau: "#0b0d18"
    readonly property color contour: "#1f6f7a"
    readonly property color texte: "#e6e8f2"
    readonly property color doux: "#9aa0bd"
    readonly property string police: "Noto Sans"
    readonly property string policeData: "Noto Sans Mono"

    // ---- mémoire (historique + mode), fichier passé par le lanceur
    readonly property var args: {
        var a = Qt.application.arguments, i = a.indexOf("--")
        return i >= 0 ? a.slice(i + 1) : []
    }
    readonly property string fichierMemoire: args.length > 0 ? args[0] : ""

    // ---- état
    property string mode: "standard"
    property bool radians: false
    property var etat: ({ saisie: "", fini: false, resultat: "", calcul: "", erreur: "" })
    property var historique: []
    property bool voirHistorique: false
    property string toucheFlash: ""
    property bool copie: false
    property bool pret: false
    property real respiration: 0.4

    // conversion
    property int cat: 0
    property int uDe: 2
    property int uVers: 3
    property string valDe: "1"
    readonly property real valeurConvertie: Calc.convertir(cat, Calc.nombre(valDe), uDe, uVers)
    readonly property string resultatConversion: Calc.formater(valeurConvertie)

    // textes de l'écran
    readonly property string apercu: etat.fini ? "" : Calc.apercu(etat.saisie, radians)
    readonly property string petitTexte: etat.erreur !== "" ? "! " + etat.erreur
                                       : etat.fini ? etat.calcul
                                       : apercu !== "" ? "= " + apercu : ""
    readonly property string grandTexte: etat.fini ? etat.resultat
                                       : etat.saisie !== "" ? Calc.afficher(etat.saisie) : "0"

    // ---- touches
    readonly property var touchesStd: [
        { l: "C", s: "effacer" }, { l: "±", s: "fn" }, { l: "%", s: "fn" }, { l: "÷", s: "op" },
        { l: "7" }, { l: "8" }, { l: "9" }, { l: "×", s: "op" },
        { l: "4" }, { l: "5" }, { l: "6" }, { l: "−", s: "op" },
        { l: "1" }, { l: "2" }, { l: "3" }, { l: "+", s: "op" },
        { l: "0", span: 2 }, { l: "," }, { l: "=", s: "egal" }
    ]
    readonly property var touchesSci: [
        { l: "sin", v: "sin(", s: "sci" }, { l: "cos", v: "cos(", s: "sci" }, { l: "tan", v: "tan(", s: "sci" }, { l: "π", s: "sci" }, { l: "e", s: "sci" },
        { l: "ln", v: "ln(", s: "sci" }, { l: "log", v: "log(", s: "sci" }, { l: "√", v: "√(", s: "sci" }, { l: "x²", s: "sci" }, { l: "xʸ", v: "^", s: "sci" },
        { l: "(", s: "sci" }, { l: ")", s: "sci" }, { l: "n!", v: "!", s: "sci" }, { l: "1/x", s: "sci" }, { l: "DEG", v: "angle", s: "fn" }
    ]
    readonly property var touchesConv: [
        { l: "7" }, { l: "8" }, { l: "9" }, { l: "C", s: "effacer" },
        { l: "4" }, { l: "5" }, { l: "6" }, { l: "⌫", s: "fn" },
        { l: "1" }, { l: "2" }, { l: "3" }, { l: "±", s: "fn" },
        { l: "0", span: 2 }, { l: "," }, { l: "⇅", s: "op" }
    ]

    function placer(liste, colonnes) {
        var r = [], col = 0, ligne = 0
        for (var i = 0; i < liste.length; i++) {
            var t = liste[i], span = t.span || 1
            if (col + span > colonnes) { col = 0; ligne++ }
            r.push({ l: t.l, v: t.v || t.l, s: t.s || "chiffre", col: col, ligne: ligne, span: span })
            col += span
            if (col >= colonnes) { col = 0; ligne++ }
        }
        return r
    }

    // contour à coins coupés (haut-gauche et bas-droite), comme partout dans CyberpunkOS
    function chemin(c, x, y, w, h, k) {
        c.beginPath()
        c.moveTo(x + k, y); c.lineTo(x + w, y); c.lineTo(x + w, y + h - k)
        c.lineTo(x + w - k, y + h); c.lineTo(x, y + h); c.lineTo(x, y + k)
        c.closePath()
    }

    // ---- actions
    function appuyer(v) {
        if (v === "angle") { radians = !radians; return }
        if (v === "⇅") { echanger(); return }
        if (mode === "conversion") { valDe = Calc.saisirNombre(valDe, v); return }
        var n = Calc.saisir(etat, v, radians)
        if (v === "=" && n.fini && !etat.fini) {
            var h = historique.slice()
            h.unshift({ c: n.calcul, r: n.resultat })
            if (h.length > 30) h.length = 30
            historique = h
            sauver()
        }
        etat = n
    }
    function reprendre(h) {
        etat = { saisie: h.r.replace(/ /g, ""), fini: true, resultat: h.r, calcul: h.c, erreur: "" }
        voirHistorique = false
    }
    function choisirCategorie(i) {
        cat = i; uDe = 0; uVers = 1; valDe = "1"
    }
    function echanger() {
        var a = uDe; uDe = uVers; uVers = a
        var r = resultatConversion.replace(/ /g, "")
        valDe = /e/.test(r) ? "0" : r
    }
    function copier() {
        var t = mode === "conversion" ? resultatConversion
              : etat.fini ? etat.resultat : (apercu !== "" ? apercu : Calc.afficher(etat.saisie))
        pressePapier.text = t.replace(/ /g, "").replace(/−/g, "-")
        pressePapier.selectAll(); pressePapier.copy()
        copie = true; timerCopie.restart()
    }
    function coller() {
        pressePapier.text = ""; pressePapier.paste()
        var t = pressePapier.text.replace(/\s/g, "").replace(/\./g, ",").replace(/\*/g, "×")
                    .replace(/\//g, "÷").replace(/-/g, "−")
        if (mode === "conversion") {
            t = t.replace(/[^0-9,−]/g, "")
            if (t !== "") valDe = t
            return
        }
        t = t.replace(/[^0-9,+−×÷^()%!πe]/g, "")
        if (t === "") return
        etat = { saisie: (etat.fini ? "" : etat.saisie) + t, fini: false, resultat: "", calcul: "", erreur: "" }
    }

    function charger() {
        if (fichierMemoire === "") return
        var x = new XMLHttpRequest()
        x.open("GET", "file://" + fichierMemoire, false)
        try {
            x.send(null)
            if (x.responseText) {
                var d = JSON.parse(x.responseText)
                historique = d.historique || []
                if (d.mode === "standard" || d.mode === "scientifique" || d.mode === "conversion") mode = d.mode
                radians = !!d.radians
            }
        } catch (e) { }
    }
    function sauver() {
        if (fichierMemoire === "" || !pret) return
        var x = new XMLHttpRequest()
        x.open("PUT", "file://" + fichierMemoire, false)
        try { x.send(JSON.stringify({ historique: historique, mode: mode, radians: radians })) } catch (e) { }
    }
    onModeChanged: sauver()
    onRadiansChanged: sauver()

    Component.onCompleted: { charger(); pret = true; racine.forceActiveFocus() }

    SequentialAnimation on respiration {
        loops: Animation.Infinite
        NumberAnimation { to: 1.0; duration: 1600; easing.type: Easing.InOutSine }
        NumberAnimation { to: 0.3; duration: 1600; easing.type: Easing.InOutSine }
    }
    Timer { id: timerFlash; interval: 130; onTriggered: win.toucheFlash = "" }
    Timer { id: timerCopie; interval: 1400; onTriggered: win.copie = false }
    TextEdit { id: pressePapier; visible: false }

    // =================================================================
    //  Éléments réutilisés
    // =================================================================
    component Cadre: Item {
        id: cadre
        property color bord: win.cyan
        property color fond: win.panneau
        property real coin: 16
        onBordChanged: toile.requestPaint()
        Canvas {
            id: toile
            anchors.fill: parent
            onWidthChanged: requestPaint()
            onHeightChanged: requestPaint()
            onPaint: {
                var c = getContext("2d"); c.reset()
                win.chemin(c, 0.5, 0.5, width - 1, height - 1, cadre.coin)
                c.fillStyle = cadre.fond; c.fill()
                c.lineWidth = 1; c.strokeStyle = cadre.bord; c.stroke()
            }
        }
    }

    component Touche: Item {
        id: t
        property string label: ""
        property string valeur: label
        property string sorte: "chiffre"     // chiffre · op · fn · effacer · egal · sci
        readonly property bool survol: zone.containsMouse
        readonly property bool enfonce: zone.pressed || (win.toucheFlash !== "" && win.toucheFlash === valeur)
        readonly property real lueur: sorte === "egal" ? win.respiration : 0
        signal clic(string v)

        readonly property color cFond: enfonce ? win.jaune
                                     : survol ? win.cyan
                                     : sorte === "egal" ? win.jaune
                                     : sorte === "op" ? Qt.rgba(1, 0.17, 0.84, 0.08)
                                     : sorte === "chiffre" ? "#10131f"
                                     : sorte === "sci" ? win.panneau
                                     : "transparent"
        readonly property color cBord: enfonce ? win.jaune
                                     : survol ? win.cyan
                                     : sorte === "egal" ? win.jaune
                                     : sorte === "op" ? win.magenta
                                     : sorte === "effacer" ? win.cyan
                                     : win.contour
        readonly property color cTexte: (enfonce || survol || sorte === "egal") ? win.nuit
                                      : sorte === "op" ? win.magenta
                                      : sorte === "chiffre" ? win.texte
                                      : win.cyan
        readonly property real epaisseur: (sorte === "op" || sorte === "effacer" || sorte === "fn") ? 2 : 1

        scale: enfonce ? 0.94 : 1.0
        Behavior on scale { NumberAnimation { duration: 70 } }
        onCFondChanged: dessin.requestPaint()
        onCBordChanged: dessin.requestPaint()
        onLueurChanged: dessin.requestPaint()

        Canvas {
            id: dessin
            anchors.fill: parent
            anchors.margins: -10                   // place pour la lueur néon
            onWidthChanged: requestPaint()
            onHeightChanged: requestPaint()
            onPaint: {
                var c = getContext("2d"); c.reset()
                var m = 10, w = width - 2 * m, h = height - 2 * m
                var k = Math.max(5, Math.min(11, h / 4))
                if (t.survol || t.enfonce) { c.shadowColor = t.enfonce ? win.jaune : win.cyan; c.shadowBlur = 16 }
                else if (t.lueur > 0) { c.shadowColor = win.jaune; c.shadowBlur = 14 * t.lueur }
                win.chemin(c, m, m, w, h, k)
                c.fillStyle = t.cFond; c.fill()
                c.shadowBlur = 0
                var e = t.epaisseur
                win.chemin(c, m + e / 2, m + e / 2, w - e, h - e, k)
                c.lineWidth = e; c.strokeStyle = t.cBord; c.stroke()
            }
        }
        Text {
            anchors.centerIn: parent
            text: t.label
            color: t.cTexte
            font.family: win.policeData
            font.bold: t.sorte !== "chiffre"
            font.pixelSize: Math.max(12, Math.min(t.height * (t.sorte === "sci" ? 0.36 : 0.42), t.width * 0.34))
        }
        MouseArea {
            id: zone
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: t.clic(t.valeur)
        }
    }

    component Clavier: Item {
        id: cl
        property var touches: []
        property int colonnes: 4
        property real ecart: 10
        readonly property var places: win.placer(touches, colonnes)
        readonly property int lignes: places.length ? places[places.length - 1].ligne + 1 : 1
        readonly property real lc: (width - (colonnes - 1) * ecart) / colonnes
        readonly property real hc: (height - (lignes - 1) * ecart) / lignes
        Repeater {
            model: cl.places
            delegate: Touche {
                x: modelData.col * (cl.lc + cl.ecart)
                y: modelData.ligne * (cl.hc + cl.ecart)
                width: modelData.span * cl.lc + (modelData.span - 1) * cl.ecart
                height: cl.hc
                label: modelData.v === "angle" ? (win.radians ? "RAD" : "DEG") : modelData.l
                valeur: modelData.v
                sorte: modelData.s
                onClic: (v) => win.appuyer(v)
            }
        }
    }

    component Puce: Rectangle {
        id: p
        property string texte: ""
        property bool actif: false
        property color teinte: win.cyan
        signal clic()
        width: lab.implicitWidth + 20; height: 28
        color: actif ? teinte : zoneP.containsMouse ? Qt.rgba(0, 0.94, 1, 0.15) : "transparent"
        border.width: 1
        border.color: actif ? teinte : zoneP.containsMouse ? win.cyan : win.contour
        Text {
            id: lab
            anchors.centerIn: parent
            text: p.texte
            color: p.actif ? win.nuit : zoneP.containsMouse ? win.cyan : "#c8cbe0"
            font.family: win.police; font.pixelSize: 13; font.bold: p.actif
        }
        MouseArea { id: zoneP; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: p.clic() }
    }

    component Lien: Text {
        id: li
        signal clic()
        font.family: win.policeData; font.pixelSize: 11; font.letterSpacing: 2
        MouseArea { anchors.fill: parent; anchors.margins: -6; cursorShape: Qt.PointingHandCursor; onClicked: li.clic() }
    }

    // =================================================================
    //  Fenêtre
    // =================================================================
    Item {
        id: racine
        anchors.fill: parent
        focus: true

        Keys.onPressed: (event) => {
            if (event.modifiers & Qt.ControlModifier) {
                if (event.key === Qt.Key_C) { win.copier(); event.accepted = true }
                else if (event.key === Qt.Key_V) { win.coller(); event.accepted = true }
                return
            }
            var k = ""
            if (event.key === Qt.Key_Return || event.key === Qt.Key_Enter) k = "="
            else if (event.key === Qt.Key_Backspace) k = "⌫"
            else if (event.key === Qt.Key_Escape || event.key === Qt.Key_Delete) {
                if (win.voirHistorique) { win.voirHistorique = false; event.accepted = true; return }
                k = "C"
            } else {
                var t = event.text
                var table = { "+": "+", "-": "−", "*": "×", "x": "×", "/": "÷", "^": "^", "(": "(", ")": ")",
                              "%": "%", "!": "!", ",": ",", ".": ",", "=": "=", "p": "π" }
                if (/^[0-9]$/.test(t)) k = t
                else if (table[t] !== undefined) k = table[t]
            }
            if (k === "") return
            if (win.mode === "conversion") {
                if (k === "−") k = "±"
                if (!/^[0-9]$/.test(k) && [",", "⌫", "C", "±"].indexOf(k) < 0) return
            }
            event.accepted = true
            win.toucheFlash = k
            timerFlash.restart()
            win.appuyer(k)
        }

        // ---- fond quadrillé qui défile doucement
        Item {
            id: grille
            anchors.fill: parent
            clip: true
            property real decal: 0
            NumberAnimation on decal { from: 0; to: 40; duration: 7000; loops: Animation.Infinite }
            Repeater {
                model: Math.ceil(win.width / 40) + 1
                Rectangle { x: index * 40; width: 1; height: grille.height; color: win.magenta; opacity: 0.06 }
            }
            Repeater {
                model: Math.ceil(win.height / 40) + 2
                Rectangle { y: index * 40 - 40 + grille.decal; height: 1; width: grille.width; color: win.magenta; opacity: 0.06 }
            }
        }

        // ---- onglets
        Row {
            id: onglets
            x: 20; y: 16
            spacing: 20
            Repeater {
                model: [["standard", "STANDARD"], ["scientifique", "SCIENTIFIQUE"], ["conversion", "CONVERSION"]]
                delegate: Item {
                    width: lo.implicitWidth; height: 26
                    readonly property bool choisi: win.mode === modelData[0]
                    Text {
                        id: lo
                        text: modelData[1]
                        color: parent.choisi ? win.jaune : zo.containsMouse ? win.cyan : win.doux
                        font.family: win.policeData; font.pixelSize: 12; font.letterSpacing: 2; font.bold: parent.choisi
                    }
                    Rectangle { anchors.bottom: parent.bottom; width: parent.width; height: 2; color: win.jaune; visible: parent.choisi }
                    MouseArea {
                        id: zo; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                        onClicked: { win.mode = modelData[0]; win.voirHistorique = false }
                    }
                }
            }
        }

        // =============================================================
        //  Standard / Scientifique
        // =============================================================
        Item {
            id: zoneCalcul
            visible: win.mode !== "conversion"
            anchors { top: onglets.bottom; topMargin: 14; left: parent.left; right: parent.right; bottom: parent.bottom; leftMargin: 20; rightMargin: 20; bottomMargin: 20 }

            Cadre {
                id: ecran
                width: parent.width
                height: Math.max(130, Math.min(170, zoneCalcul.height * 0.27))

                Text {
                    id: petit
                    anchors { top: parent.top; topMargin: 14; left: parent.left; leftMargin: 20; right: parent.right; rightMargin: 20 }
                    horizontalAlignment: Text.AlignRight
                    elide: Text.ElideLeft
                    text: win.petitTexte
                    color: win.etat.erreur !== "" ? win.magenta : win.cyan
                    font.family: win.policeData; font.pixelSize: 15
                }
                Text {
                    id: grand
                    anchors { top: petit.bottom; left: parent.left; leftMargin: 20; right: parent.right; rightMargin: 28; bottom: basEcran.top; bottomMargin: 2 }
                    horizontalAlignment: Text.AlignRight
                    verticalAlignment: Text.AlignVCenter
                    fontSizeMode: Text.Fit
                    minimumPixelSize: 16
                    font.pixelSize: 50
                    font.bold: true
                    font.family: win.policeData
                    color: win.jaune
                    text: win.grandTexte
                }
                Rectangle {
                    id: curseur
                    visible: !win.etat.fini
                    anchors { right: parent.right; rightMargin: 18; verticalCenter: grand.verticalCenter }
                    width: 3; height: Math.min(grand.height * 0.7, 44)
                    color: win.jaune
                    SequentialAnimation on opacity {
                        loops: Animation.Infinite
                        NumberAnimation { to: 0.1; duration: 500 }
                        NumberAnimation { to: 1.0; duration: 500 }
                    }
                }
                Item {
                    id: basEcran
                    anchors { left: parent.left; leftMargin: 20; right: parent.right; rightMargin: 18; bottom: parent.bottom; bottomMargin: 10 }
                    height: 22
                    Lien {
                        anchors.verticalCenter: parent.verticalCenter
                        text: (win.voirHistorique ? "// HISTORIQUE ▾ " : "// HISTORIQUE ▸ ") + win.historique.length
                        color: win.magenta
                        onClic: win.voirHistorique = !win.voirHistorique
                    }
                    Row {
                        anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter
                        spacing: 18
                        Lien {
                            anchors.verticalCenter: parent.verticalCenter
                            text: win.copie ? "COPIÉ ✓" : "COPIER"
                            color: win.copie ? win.jaune : win.cyan
                            onClic: win.copier()
                        }
                        Lien {
                            anchors.verticalCenter: parent.verticalCenter
                            text: "⌫"; font.pixelSize: 18; font.letterSpacing: 0
                            color: win.cyan
                            onClic: win.appuyer("⌫")
                        }
                    }
                }
            }

            Item {
                id: zoneTouches
                anchors { top: ecran.bottom; topMargin: 16; left: parent.left; right: parent.right; bottom: parent.bottom }

                Clavier {
                    id: clavierSci
                    visible: win.mode === "scientifique"
                    width: parent.width
                    height: visible ? parent.height * 0.36 : 0
                    touches: win.touchesSci
                    colonnes: 5
                    ecart: 8
                }
                Clavier {
                    anchors { top: clavierSci.bottom; topMargin: clavierSci.visible ? 10 : 0; bottom: parent.bottom }
                    width: parent.width
                    touches: win.touchesStd
                    colonnes: 4
                    ecart: win.mode === "scientifique" ? 8 : 10
                }

                // ---- historique (par-dessus les touches)
                Rectangle {
                    anchors.fill: parent
                    visible: win.voirHistorique
                    color: win.panneau
                    border.color: win.cyan; border.width: 1
                    MouseArea { anchors.fill: parent }          // bloque les clics vers les touches

                    Text {
                        id: titreHisto
                        x: 16; y: 14
                        text: "// HISTORIQUE"
                        color: win.magenta
                        font.family: win.policeData; font.pixelSize: 12; font.letterSpacing: 3
                    }
                    Row {
                        anchors { right: parent.right; rightMargin: 16; verticalCenter: titreHisto.verticalCenter }
                        spacing: 20
                        Lien { text: "EFFACER"; color: win.cyan; visible: win.historique.length > 0; onClic: { win.historique = []; win.sauver() } }
                        Lien { text: "✕"; font.pixelSize: 15; color: win.cyan; onClic: win.voirHistorique = false }
                    }
                    ListView {
                        anchors { top: titreHisto.bottom; topMargin: 12; left: parent.left; right: parent.right; bottom: parent.bottom; margins: 12 }
                        clip: true
                        spacing: 6
                        model: win.historique
                        delegate: Rectangle {
                            width: ListView.view.width
                            height: 56
                            color: zh.containsMouse ? Qt.rgba(0, 0.94, 1, 0.12) : "transparent"
                            border.width: 1
                            border.color: zh.containsMouse ? win.cyan : "transparent"
                            Rectangle { width: 3; height: parent.height; color: index === 0 ? win.jaune : win.cyan }
                            Text {
                                x: 14; y: 7; width: parent.width - 28
                                text: modelData.c
                                elide: Text.ElideLeft
                                color: win.doux
                                font.family: win.policeData; font.pixelSize: 13
                            }
                            Text {
                                anchors { right: parent.right; rightMargin: 12; bottom: parent.bottom; bottomMargin: 5 }
                                text: modelData.r
                                color: win.jaune
                                font.family: win.policeData; font.pixelSize: 20; font.bold: true
                            }
                            MouseArea { id: zh; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: win.reprendre(modelData) }
                        }
                    }
                    Text {
                        anchors.centerIn: parent
                        visible: win.historique.length === 0
                        text: "Aucun calcul pour l'instant"
                        color: win.doux
                        font.family: win.police; font.pixelSize: 14
                    }
                }
            }
        }

        // =============================================================
        //  Conversion
        // =============================================================
        Item {
            id: zoneConversion
            visible: win.mode === "conversion"
            anchors { top: onglets.bottom; topMargin: 14; left: parent.left; right: parent.right; bottom: parent.bottom; leftMargin: 20; rightMargin: 20; bottomMargin: 20 }

            Column {
                id: colConversion
                width: parent.width
                spacing: 10

                Flow {
                    width: parent.width
                    spacing: 6
                    Repeater {
                        model: Calc.CONVERSIONS
                        delegate: Puce { texte: modelData.nom; actif: index === win.cat; teinte: win.jaune; onClic: win.choisirCategorie(index) }
                    }
                }

                Cadre {
                    width: parent.width
                    height: colDe.implicitHeight + 24
                    coin: 14
                    Column {
                        id: colDe
                        x: 14; y: 12; width: parent.width - 28
                        spacing: 8
                        Item {
                            width: parent.width; height: 36
                            Text { anchors.verticalCenter: parent.verticalCenter; text: "// DE"; color: win.magenta; font.family: win.policeData; font.pixelSize: 11; font.letterSpacing: 3 }
                            Text {
                                anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                                width: parent.width - 60
                                horizontalAlignment: Text.AlignRight
                                fontSizeMode: Text.HorizontalFit; minimumPixelSize: 14
                                text: Calc.afficher(win.valDe)
                                color: win.jaune
                                font.family: win.policeData; font.pixelSize: 30; font.bold: true
                            }
                        }
                        Flow {
                            width: parent.width; spacing: 6
                            Repeater {
                                model: Calc.CONVERSIONS[win.cat].unites
                                delegate: Puce { texte: modelData[0]; actif: index === win.uDe; onClic: win.uDe = index }
                            }
                        }
                    }
                }

                Item {
                    width: parent.width; height: 28
                    Puce { anchors.centerIn: parent; texte: "⇅  Inverser"; onClic: win.echanger() }
                }

                Cadre {
                    width: parent.width
                    height: colVers.implicitHeight + 24
                    coin: 14
                    bord: win.magenta
                    Column {
                        id: colVers
                        x: 14; y: 12; width: parent.width - 28
                        spacing: 8
                        Item {
                            width: parent.width; height: 36
                            Text { anchors.verticalCenter: parent.verticalCenter; text: "// VERS"; color: win.magenta; font.family: win.policeData; font.pixelSize: 11; font.letterSpacing: 3 }
                            Text {
                                anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                                width: parent.width - 70
                                horizontalAlignment: Text.AlignRight
                                fontSizeMode: Text.HorizontalFit; minimumPixelSize: 14
                                text: win.resultatConversion
                                color: win.cyan
                                font.family: win.policeData; font.pixelSize: 30; font.bold: true
                            }
                        }
                        Flow {
                            width: parent.width; spacing: 6
                            Repeater {
                                model: Calc.CONVERSIONS[win.cat].unites
                                delegate: Puce { texte: modelData[0]; actif: index === win.uVers; onClic: win.uVers = index }
                            }
                        }
                    }
                }
            }

            Clavier {
                anchors { top: colConversion.bottom; topMargin: 14; bottom: parent.bottom }
                width: parent.width
                touches: win.touchesConv
                colonnes: 4
                ecart: 8
            }
        }
    }
}
