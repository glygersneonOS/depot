// =====================================================================
//  Notes CyberpunkOS (croquis validé le 11/11/2026)
//  Liste + recherche + étiquettes à gauche, éditeur à droite (gras, italique, barré,
//  couleurs, cases à cocher cliquables, puces), enregistrement automatique.
//  Lancée par cyberpunkos-notes :  qml Notes.qml -- <fichier de mémoire>
// =====================================================================
import QtQuick
import QtQuick.Window
import "notes.js" as N

Window {
    id: win
    visible: true
    width: 1100; height: 700
    minimumWidth: 760; minimumHeight: 480
    color: nuit
    title: courante && courante.titre ? courante.titre + " — Notes" : "Notes"

    // ---- couleurs CyberpunkOS
    readonly property color jaune: "#f5e400"
    readonly property color cyan: "#00f0ff"
    readonly property color magenta: "#ff2bd6"
    readonly property color nuit: "#07080f"
    readonly property color panneau: "#0b0d18"
    readonly property color contour: "#1f6f7a"
    readonly property color texte: "#e6e8f2"
    readonly property color doux: "#9aa0bd"
    readonly property string police: "Noto Sans"
    readonly property string policeData: "Noto Sans Mono"

    readonly property var args: {
        var a = Qt.application.arguments, i = a.indexOf("--")
        return i >= 0 ? a.slice(i + 1) : []
    }
    readonly property string fichierMemoire: args.length > 0 ? args[0] : ""

    // ---- état
    property var notes: []
    property string idCourant: ""
    property string filtre: "tout"
    property string recherche: ""
    property bool enChargement: false
    property bool modifie: false
    property bool confirmerSuppression: false
    property real maintenant: Date.now()
    readonly property var visibles: N.filtrer(notes, filtre, recherche)
    readonly property var courante: trouver(idCourant, notes)

    function trouver(id, liste) {
        for (var i = 0; i < liste.length; i++) if (liste[i].id === id) return liste[i]
        return null
    }

    // ---- fichier
    function charger() {
        var d = null
        if (fichierMemoire !== "") {
            var x = new XMLHttpRequest()
            x.open("GET", "file://" + fichierMemoire, false)
            try { x.send(null); if (x.responseText) d = JSON.parse(x.responseText) } catch (e) { d = null }
        }
        var liste = d && d.notes ? d.notes : []
        if (liste.length === 0) liste = [N.bienvenue(Date.now())]
        notes = liste
        var id = d && d.selection && trouver(d.selection, liste) ? d.selection : N.filtrer(liste, "tout", "")[0].id
        ouvrir(id)
    }
    function sauverFichier() {
        if (fichierMemoire === "") return
        var x = new XMLHttpRequest()
        x.open("PUT", "file://" + fichierMemoire, false)
        try { x.send(JSON.stringify({ notes: notes, selection: idCourant })) } catch (e) { }
    }

    // ---- notes
    function remplacer(id, champs) {
        var arr = []
        for (var i = 0; i < notes.length; i++) {
            var n = notes[i]
            if (n.id === id) {
                var c = {}
                for (var k in n) c[k] = n[k]
                for (var k2 in champs) c[k2] = champs[k2]
                n = c
            }
            arr.push(n)
        }
        notes = arr
    }
    function enregistrer() {
        timerSauve.stop()
        if (!modifie || idCourant === "") return
        var txt = editeur.getText(0, editeur.length)
        remplacer(idCourant, { titre: titre.text, html: editeur.getFormattedText(0, editeur.length),
                               texte: txt, modif: Date.now() })
        modifie = false
        maintenant = Date.now()
        sauverFichier()
    }
    function ouvrir(id) {
        enregistrer()
        idCourant = id
        var n = trouver(id, notes)
        enChargement = true
        titre.text = n ? n.titre : ""
        editeur.text = n ? n.html : ""
        enChargement = false
        modifie = false
        confirmerSuppression = false
        flick.contentY = 0
        sauverFichier()
    }
    function changement() {
        if (enChargement) return
        modifie = true
        timerSauve.restart()
    }
    function nouvelle() {
        enregistrer()
        var n = N.nouvelleNote(filtre !== "tout" ? filtre : "", Date.now())
        notes = [n].concat(notes)
        recherche = ""; champRecherche.text = ""
        ouvrir(n.id)
        titre.forceActiveFocus()
    }
    function supprimer() {
        if (!confirmerSuppression) { confirmerSuppression = true; timerConfirmation.restart(); return }
        timerSauve.stop()
        modifie = false
        var arr = []
        for (var i = 0; i < notes.length; i++) if (notes[i].id !== idCourant) arr.push(notes[i])
        if (arr.length === 0) arr = [N.nouvelleNote("", Date.now())]
        notes = arr
        idCourant = ""
        var v = N.filtrer(arr, filtre, recherche)
        ouvrir(v.length ? v[0].id : N.filtrer(arr, "tout", "")[0].id)
    }
    function changerEtiquette(e) {
        if (!courante) return
        enregistrer()
        remplacer(idCourant, { etiquette: courante.etiquette === e ? "" : e, modif: Date.now() })
        maintenant = Date.now()
        sauverFichier()
    }

    // ---- mise en forme (Qt 6.7 et + : cursorSelection ; sinon on entoure la sélection de balises)
    function entourer(avant, apres) {
        var a = editeur.selectionStart, b = editeur.selectionEnd
        if (a === b) return
        var t = editeur.selectedText
        editeur.remove(a, b)
        editeur.insert(a, avant + N.echapper(t).split(N.SEPARATEURS).join("<br>") + apres)
    }
    function basculerStyle(nom, balise) {
        try {
            var s = editeur.cursorSelection
            var f = s.font
            f[nom] = !f[nom]
            s.font = f
        } catch (e) {
            entourer("<" + balise + ">", "</" + balise + ">")
        }
        changement()
        editeur.forceActiveFocus()
    }
    function couleurTexte(c) {
        try {
            editeur.cursorSelection.color = c
        } catch (e) {
            entourer("<span style=\"color:" + c + "\">", "</span>")
        }
        changement()
        editeur.forceActiveFocus()
    }
    function appliquerLigne(action, d, garderCurseur) {
        var cur = editeur.cursorPosition
        if (action.retirer > 0) editeur.remove(d, d + action.retirer)
        if (action.inserer !== "") editeur.insert(d, action.inserer)
        if (garderCurseur) editeur.cursorPosition = Math.max(d, Math.min(cur + action.decalage, editeur.length))
        changement()
    }
    function basculerCase(pos) {
        var t = editeur.getText(0, editeur.length)
        var d = N.debutLigne(t, pos === undefined ? editeur.cursorPosition : pos)
        appliquerLigne(N.actionCase(t, d), d, true)
        editeur.forceActiveFocus()
    }
    function basculerPuce() {
        var t = editeur.getText(0, editeur.length)
        var d = N.debutLigne(t, editeur.cursorPosition)
        appliquerLigne(N.actionPuce(t, d), d, true)
        editeur.forceActiveFocus()
    }

    function entree(event) {
        var t = editeur.getText(0, editeur.length)
        var a = N.actionEntree(t, editeur.cursorPosition)
        if (a === null) { event.accepted = false; return }
        event.accepted = true
        if (a.finir) { editeur.remove(a.debut, a.debut + 2); return }
        var pos = editeur.cursorPosition
        editeur.insert(pos, "\n" + a.suite)
        editeur.cursorPosition = pos + 1 + a.suite.length
    }

    Component.onCompleted: charger()
    onClosing: (close) => { win.enregistrer() }

    Timer { id: timerSauve; interval: 800; onTriggered: win.enregistrer() }
    Timer { id: timerConfirmation; interval: 3000; onTriggered: win.confirmerSuppression = false }
    Timer { interval: 30000; running: true; repeat: true; onTriggered: win.maintenant = Date.now() }

    Shortcut { sequence: "Ctrl+N"; onActivated: win.nouvelle() }
    Shortcut { sequence: "Ctrl+F"; onActivated: champRecherche.forceActiveFocus() }
    Shortcut { sequence: "Ctrl+S"; onActivated: win.enregistrer() }
    Shortcut { sequence: "Ctrl+B"; onActivated: win.basculerStyle("bold", "b") }
    Shortcut { sequence: "Ctrl+I"; onActivated: win.basculerStyle("italic", "i") }
    Shortcut { sequence: "Ctrl+U"; onActivated: win.basculerStyle("underline", "u") }

    // =================================================================
    //  Éléments réutilisés
    // =================================================================
    component Puce: Rectangle {
        id: p
        property string texte: ""
        property bool actif: false
        property color teinte: win.cyan
        signal clic()
        width: lab.implicitWidth + 16; height: 24
        color: actif ? teinte : zp.containsMouse ? Qt.rgba(0, 0.94, 1, 0.12) : "transparent"
        border.width: 1
        border.color: actif ? teinte : zp.containsMouse ? win.cyan : teinte
        Text {
            id: lab
            anchors.centerIn: parent
            text: p.texte
            color: p.actif ? win.nuit : p.teinte
            font.family: win.policeData; font.pixelSize: 11; font.letterSpacing: 1; font.bold: p.actif
        }
        MouseArea { id: zp; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: p.clic() }
    }

    component Outil: Rectangle {
        id: o
        property string texte: ""
        property string aide: ""
        property bool gras: false
        property bool italique: false
        property bool barre: false
        property bool souligne: false
        property color pastille: "transparent"
        signal clic()
        width: 36; height: 32
        color: zo.pressed ? win.jaune : zo.containsMouse ? win.cyan : "transparent"
        border.width: 1
        border.color: zo.containsMouse ? win.cyan : "transparent"
        Text {
            anchors.centerIn: parent
            visible: o.texte !== ""
            text: o.texte
            color: zo.containsMouse || zo.pressed ? win.nuit : win.cyan
            font.family: win.police; font.pixelSize: 16
            font.bold: o.gras; font.italic: o.italique; font.strikeout: o.barre; font.underline: o.souligne
        }
        Rectangle {
            anchors.centerIn: parent
            visible: o.texte === ""
            width: 14; height: 14
            color: o.pastille
            border.width: zo.containsMouse ? 2 : 0; border.color: win.nuit
        }
        MouseArea { id: zo; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: o.clic() }
    }

    component Lien: Text {
        id: li
        signal clic()
        font.family: win.policeData; font.pixelSize: 11; font.letterSpacing: 2
        MouseArea { anchors.fill: parent; anchors.margins: -6; cursorShape: Qt.PointingHandCursor; onClicked: li.clic() }
    }

    // =================================================================
    //  Fond quadrillé qui défile doucement
    // =================================================================
    Item {
        id: grille
        anchors.fill: parent
        clip: true
        property real decal: 0
        NumberAnimation on decal { from: 0; to: 40; duration: 7000; loops: Animation.Infinite }
        Repeater {
            model: Math.ceil(win.width / 40) + 1
            Rectangle { x: index * 40; width: 1; height: grille.height; color: win.magenta; opacity: 0.06 }
        }
        Repeater {
            model: Math.ceil(win.height / 40) + 2
            Rectangle { y: index * 40 - 40 + grille.decal; height: 1; width: grille.width; color: win.magenta; opacity: 0.06 }
        }
    }

    // =================================================================
    //  Colonne de gauche : nouvelle note, recherche, étiquettes, liste
    // =================================================================
    Rectangle {
        id: cote
        width: 300
        anchors { top: parent.top; bottom: parent.bottom; left: parent.left }
        color: Qt.rgba(0.043, 0.05, 0.094, 0.88)
        Rectangle { anchors { top: parent.top; bottom: parent.bottom; right: parent.right }
                    width: 1; color: win.contour }

        Column {
            id: hautCote
            x: 18; y: 18
            width: parent.width - 36
            spacing: 14

            // bouton « + Nouvelle note » à coins coupés
            Item {
                width: parent.width; height: 44
                Canvas {
                    id: toileBouton
                    anchors.fill: parent
                    property bool survol: zb.containsMouse
                    onSurvolChanged: requestPaint()
                    onPaint: {
                        var c = getContext("2d"); c.reset()
                        var k = 10, w = width, h = height
                        c.beginPath(); c.moveTo(k, 0); c.lineTo(w, 0); c.lineTo(w, h - k); c.lineTo(w - k, h); c.lineTo(0, h); c.lineTo(0, k); c.closePath()
                        c.fillStyle = survol ? "#fff36b" : win.jaune; c.fill()
                    }
                }
                Text { anchors.centerIn: parent; text: "+ Nouvelle note"; color: win.nuit; font.family: win.police; font.pixelSize: 15; font.bold: true }
                MouseArea { id: zb; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: win.nouvelle() }
            }

            // recherche
            Rectangle {
                width: parent.width; height: 38
                color: win.panneau
                border.width: 1
                border.color: champRecherche.activeFocus ? win.cyan : win.contour
                Canvas {
                    x: 10; anchors.verticalCenter: parent.verticalCenter
                    width: 18; height: 18
                    onPaint: {
                        var c = getContext("2d"); c.reset()
                        c.strokeStyle = win.cyan; c.lineWidth = 2
                        c.beginPath(); c.arc(7.5, 7.5, 5.5, 0, Math.PI * 2); c.stroke()
                        c.beginPath(); c.moveTo(11.5, 11.5); c.lineTo(17, 17); c.stroke()
                    }
                }
                TextInput {
                    id: champRecherche
                    anchors { left: parent.left; leftMargin: 36; right: effacerRecherche.left; rightMargin: 6; verticalCenter: parent.verticalCenter }
                    color: win.texte
                    selectionColor: win.cyan; selectedTextColor: win.nuit
                    font.family: win.police; font.pixelSize: 14
                    clip: true
                    onTextChanged: win.recherche = text
                    Keys.onEscapePressed: { text = ""; editeur.forceActiveFocus() }
                    Text {
                        visible: champRecherche.text === "" && !champRecherche.activeFocus
                        text: "Rechercher…"
                        color: win.doux
                        font: champRecherche.font
                    }
                }
                Text {
                    id: effacerRecherche
                    anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
                    visible: champRecherche.text !== ""
                    text: "✕"; color: win.cyan; font.pixelSize: 13
                    MouseArea { anchors.fill: parent; anchors.margins: -6; cursorShape: Qt.PointingHandCursor; onClicked: champRecherche.text = "" }
                }
            }

            // filtres par étiquette
            Flow {
                width: parent.width
                spacing: 6
                Puce { texte: "TOUT"; actif: win.filtre === "tout"; teinte: win.cyan; onClic: win.filtre = "tout" }
                Repeater {
                    model: N.ETIQUETTES
                    delegate: Puce { texte: modelData.nom; teinte: modelData.couleur; actif: win.filtre === modelData.id; onClic: win.filtre = modelData.id }
                }
            }

            Text {
                text: win.visibles.length + (win.visibles.length > 1 ? " notes" : " note")
                color: win.doux
                font.family: win.policeData; font.pixelSize: 11; font.letterSpacing: 2
            }
        }

        ListView {
            id: liste
            anchors { top: hautCote.bottom; topMargin: 10; left: parent.left; right: parent.right; bottom: parent.bottom; leftMargin: 18; rightMargin: 18; bottomMargin: 14 }
            clip: true
            spacing: 8
            model: win.visibles
            delegate: Item {
                id: carte
                width: ListView.view.width
                height: 62
                readonly property bool choisie: modelData.id === win.idCourant
                readonly property color teinte: N.couleurEtiquette(modelData.etiquette)
                Canvas {
                    anchors.fill: parent
                    property bool c1: carte.choisie
                    property bool c2: zc.containsMouse
                    onC1Changed: requestPaint()
                    onC2Changed: requestPaint()
                    onPaint: {
                        var c = getContext("2d"); c.reset()
                        var w = width, h = height, k = 10
                        c.beginPath(); c.moveTo(0, 0); c.lineTo(w, 0); c.lineTo(w, h - k); c.lineTo(w - k, h); c.lineTo(0, h); c.closePath()
                        c.fillStyle = carte.choisie ? win.jaune : zc.containsMouse ? Qt.rgba(0, 0.94, 1, 0.12) : "transparent"
                        c.fill()
                        if (!carte.choisie) { c.fillStyle = carte.teinte; c.fillRect(0, 0, 3, h) }
                    }
                }
                Text {
                    anchors { left: parent.left; leftMargin: 14; right: dateNote.left; rightMargin: 8; top: parent.top; topMargin: 9 }
                    text: modelData.titre !== "" ? modelData.titre : "Sans titre"
                    elide: Text.ElideRight
                    color: carte.choisie ? win.nuit : (zc.containsMouse ? win.cyan : win.texte)
                    font.family: win.police; font.pixelSize: 15; font.bold: true
                    font.italic: modelData.titre === ""
                }
                Text {
                    id: dateNote
                    anchors { right: parent.right; rightMargin: 12; top: parent.top; topMargin: 11 }
                    text: N.dateCourte(modelData.modif, win.maintenant)
                    color: carte.choisie ? win.nuit : win.doux
                    font.family: win.policeData; font.pixelSize: 11
                }
                Text {
                    anchors { left: parent.left; leftMargin: 14; right: parent.right; rightMargin: 14; bottom: parent.bottom; bottomMargin: 9 }
                    text: N.apercu(modelData.texte)
                    elide: Text.ElideRight
                    color: carte.choisie ? win.nuit : win.doux
                    font.family: win.police; font.pixelSize: 12
                }
                MouseArea { id: zc; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: win.ouvrir(modelData.id) }
            }
            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                y: 20
                visible: win.visibles.length === 0
                text: win.recherche !== "" ? "Aucune note trouvée" : "Aucune note ici"
                color: win.doux
                font.family: win.police; font.pixelSize: 14
            }
        }
    }

    // =================================================================
    //  Éditeur
    // =================================================================
    Item {
        id: zoneEditeur
        anchors { top: parent.top; bottom: parent.bottom; left: cote.right; right: parent.right; leftMargin: 40; rightMargin: 40; topMargin: 26; bottomMargin: 16 }

        Column {
            id: entete
            width: parent.width
            spacing: 8

            Text {
                text: "// " + N.nomEtiquette(win.courante ? win.courante.etiquette : "") + " · "
                      + (win.courante ? N.dateLongue(win.courante.modif, win.maintenant) : "")
                color: win.magenta
                font.family: win.policeData; font.pixelSize: 12; font.letterSpacing: 4
            }
            TextInput {
                id: titre
                width: parent.width
                color: win.jaune
                selectionColor: win.cyan; selectedTextColor: win.nuit
                font.family: win.police; font.pixelSize: 32; font.bold: true
                clip: true
                onTextChanged: win.changement()
                Keys.onReturnPressed: editeur.forceActiveFocus()
                Keys.onEnterPressed: editeur.forceActiveFocus()
                Text {
                    visible: titre.text === ""
                    text: "Sans titre"
                    color: Qt.rgba(0.96, 0.89, 0, 0.35)
                    font: titre.font
                }
            }
            Rectangle { width: 120; height: 3; color: win.jaune }

            Item {
                width: parent.width; height: 30
                Row {
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: 6
                    Repeater {
                        model: N.ETIQUETTES
                        delegate: Puce {
                            texte: modelData.nom; teinte: modelData.couleur
                            actif: win.courante !== null && win.courante.etiquette === modelData.id
                            onClic: win.changerEtiquette(modelData.id)
                        }
                    }
                }
                Lien {
                    anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                    text: win.confirmerSuppression ? "CONFIRMER LA SUPPRESSION ?" : "SUPPRIMER"
                    color: win.magenta
                    font.bold: win.confirmerSuppression
                    onClic: win.supprimer()
                }
            }

            // barre d'outils
            Rectangle {
                width: barre.width + 12; height: 44
                color: win.panneau
                border.width: 1; border.color: win.contour
                Row {
                    id: barre
                    x: 6; anchors.verticalCenter: parent.verticalCenter
                    spacing: 4
                    Outil { texte: "B"; gras: true; onClic: win.basculerStyle("bold", "b") }
                    Outil { texte: "I"; italique: true; onClic: win.basculerStyle("italic", "i") }
                    Outil { texte: "S"; souligne: true; onClic: win.basculerStyle("underline", "u") }
                    Outil { texte: "ab"; barre: true; onClic: win.basculerStyle("strikeout", "s") }
                    Rectangle { width: 1; height: 24; color: win.contour; anchors.verticalCenter: parent.verticalCenter }
                    Outil { texte: "☑"; onClic: win.basculerCase() }
                    Outil { texte: "•"; onClic: win.basculerPuce() }
                    Rectangle { width: 1; height: 24; color: win.contour; anchors.verticalCenter: parent.verticalCenter }
                    Outil { pastille: win.jaune; onClic: win.couleurTexte("#f5e400") }
                    Outil { pastille: win.cyan; onClic: win.couleurTexte("#00f0ff") }
                    Outil { pastille: win.magenta; onClic: win.couleurTexte("#ff2bd6") }
                    Outil { pastille: win.texte; onClic: win.couleurTexte("#e6e8f2") }
                }
            }
        }

        // texte de la note
        Flickable {
            id: flick
            anchors { top: entete.bottom; topMargin: 18; left: parent.left; right: parent.right; bottom: pied.top; bottomMargin: 8 }
            clip: true
            contentWidth: width
            contentHeight: Math.max(editeur.contentHeight + 20, height)
            boundsBehavior: Flickable.StopAtBounds

            function suivre(r) {
                if (contentY >= r.y) contentY = r.y
                else if (contentY + height <= r.y + r.height) contentY = r.y + r.height - height
            }

            TextEdit {
                id: editeur
                width: flick.width
                height: Math.max(contentHeight, flick.height)
                textFormat: TextEdit.RichText
                wrapMode: TextEdit.Wrap
                color: win.texte
                selectionColor: win.cyan
                selectedTextColor: win.nuit
                selectByMouse: true
                persistentSelection: true
                font.family: win.police; font.pixelSize: 17
                onTextChanged: win.changement()
                onCursorRectangleChanged: flick.suivre(cursorRectangle)

                // Entrée sur une ligne à cocher / à puces : la liste continue (ou s'arrête si la ligne est vide)
                Keys.onReturnPressed: (event) => { win.entree(event) }
                Keys.onEnterPressed: (event) => { win.entree(event) }

                // clic sur ☐ / ☑ en début de ligne : la case se coche
                TapHandler {
                    acceptedButtons: Qt.LeftButton
                    onTapped: (eventPoint, button) => {
                        var pos = editeur.positionAt(eventPoint.position.x, eventPoint.position.y)
                        var t = editeur.getText(0, editeur.length)
                        var d = N.debutLigne(t, pos)
                        var p = N.prefixe(t, d)
                        if ((p === "☐ " || p === "☑ ") && pos - d <= 1) win.basculerCase(pos)
                    }
                }

                Text {
                    visible: editeur.length === 0 && !editeur.activeFocus
                    text: "Écris ta note ici…"
                    color: win.doux
                    font: editeur.font
                }
            }
        }

        Text {
            id: pied
            anchors { right: parent.right; bottom: parent.bottom }
            text: win.modifie ? "● Enregistrement…" : "● Enregistré automatiquement"
            color: win.modifie ? win.jaune : win.cyan
            font.family: win.policeData; font.pixelSize: 12
        }
        Text {
            anchors { left: parent.left; bottom: parent.bottom }
            text: "Ctrl+N nouvelle note · Ctrl+F rechercher · Ctrl+B gras · Ctrl+I italique"
            color: Qt.rgba(0.6, 0.63, 0.74, 0.6)
            font.family: win.policeData; font.pixelSize: 11
        }
    }
}
