.pragma library
// =====================================================================
//  notes.js — logique de l'appli Notes CyberpunkOS (sans interface)
//  filtres et recherche, dates en français, lignes à cocher (☐ / ☑) et à puces (•)
// =====================================================================

var ETIQUETTES = [
    { id: "projets", nom: "PROJETS", couleur: "#00f0ff" },
    { id: "perso",   nom: "PERSO",   couleur: "#ff2bd6" },
    { id: "idees",   nom: "IDÉES",   couleur: "#f5e400" }
]

function couleurEtiquette(id) {
    for (var i = 0; i < ETIQUETTES.length; i++) if (ETIQUETTES[i].id === id) return ETIQUETTES[i].couleur
    return "#1f6f7a"
}
function nomEtiquette(id) {
    for (var i = 0; i < ETIQUETTES.length; i++) if (ETIQUETTES[i].id === id) return ETIQUETTES[i].nom
    return "SANS ÉTIQUETTE"
}

// séparateurs de lignes : retour à la ligne + séparateurs de paragraphe de Qt (U+2028, U+2029)
var SEPARATEURS = new RegExp("[\\n" + String.fromCharCode(0x2028, 0x2029) + "]")

// ---------- texte ----------
function echapper(t) {
    return String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
}
function texteDe(html) {                         // texte brut d'un morceau de HTML
    return String(html).replace(/<style[\s\S]*?<\/style>/gi, "").replace(/<br\s*\/?>/gi, "\n")
        .replace(/<\/p>/gi, "\n").replace(/<[^>]+>/g, "")
        .replace(/&nbsp;/g, " ").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, "\"")
        .replace(/&#39;/g, "'").replace(/&amp;/g, "&").replace(/\n{3,}/g, "\n\n").trim()
}
function sansAccents(s) {
    s = String(s).toLowerCase()
    return typeof s.normalize === "function" ? s.normalize("NFD").replace(/[̀-ͯ]/g, "") : s
}
function apercu(texte) {                         // première ligne utile, pour la liste
    var lignes = String(texte || "").split(SEPARATEURS)
    for (var i = 0; i < lignes.length; i++) {
        var l = lignes[i].replace(/^[☐☑•]\s*/, "").trim()
        if (l !== "") return l.length > 60 ? l.substring(0, 60) + "…" : l
    }
    return "Note vide"
}

// ---------- liste ----------
function filtrer(notes, filtre, recherche) {
    var q = sansAccents(String(recherche || "").trim())
    var r = []
    for (var i = 0; i < notes.length; i++) {
        var n = notes[i]
        if (filtre && filtre !== "tout" && n.etiquette !== filtre) continue
        if (q !== "" && sansAccents((n.titre || "") + "\n" + (n.texte || "")).indexOf(q) < 0) continue
        r.push(n)
    }
    r.sort(function (a, b) { return (b.modif || 0) - (a.modif || 0) })
    return r
}

function deux(n) { return n < 10 ? "0" + n : "" + n }
function memeJour(a, b) {
    return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate()
}
function dateCourte(ts, maintenant) {            // pour la liste : 20:37 · hier · 09/11
    var d = new Date(ts), m = new Date(maintenant)
    if (memeJour(d, m)) return deux(d.getHours()) + ":" + deux(d.getMinutes())
    var hier = new Date(maintenant - 86400000)
    if (memeJour(d, hier)) return "hier"
    return deux(d.getDate()) + "/" + deux(d.getMonth() + 1)
}
function dateLongue(ts, maintenant) {            // pour l'en-tête : MODIFIÉE À 20:37
    var d = new Date(ts), m = new Date(maintenant)
    var h = deux(d.getHours()) + ":" + deux(d.getMinutes())
    if (memeJour(d, m)) return "MODIFIÉE À " + h
    if (memeJour(d, new Date(maintenant - 86400000))) return "MODIFIÉE HIER À " + h
    return "MODIFIÉE LE " + deux(d.getDate()) + "/" + deux(d.getMonth() + 1) + " À " + h
}

function nouvelleNote(etiquette, maintenant) {
    return { id: "n" + maintenant + Math.floor(Math.random() * 1000), titre: "", html: "", texte: "",
             etiquette: etiquette || "", modif: maintenant }
}
function bienvenue(maintenant) {
    var html = "<p>Bienvenue dans <b>Notes</b>, l'appli de notes de CyberpunkOS.</p>"
             + "<p>☐ Clique sur une case pour la cocher</p>"
             + "<p>☑ Les notes s'enregistrent toutes seules</p>"
             + "<p>• Sélectionne du texte pour le mettre en <b>gras</b>, en <i>italique</i> ou en couleur</p>"
             + "<p>• Ctrl+N : nouvelle note · Ctrl+F : rechercher</p>"
    return { id: "n" + maintenant, titre: "Bienvenue dans Notes", html: html, texte: texteDe(html),
             etiquette: "idees", modif: maintenant }
}

// ---------- lignes à cocher / à puces ----------
function debutLigne(texte, pos) {
    var s = String(texte)
    pos = Math.max(0, Math.min(pos, s.length))
    for (var i = pos - 1; i >= 0; i--) if (SEPARATEURS.test(s.charAt(i))) return i + 1
    return 0
}
function ligne(texte, debut) {
    var s = String(texte), i = debut
    while (i < s.length && !SEPARATEURS.test(s.charAt(i))) i++
    return s.substring(debut, i)
}
function prefixe(texte, debut) {
    var l = ligne(texte, debut)
    var deb = l.substring(0, 2)
    return (deb === "☐ " || deb === "☑ " || deb === "• ") ? deb : ""
}
// ce qu'il faut faire sur la ligne pour basculer une case : { retirer: n caractères, inserer: texte }
function actionCase(texte, debut) {
    var p = prefixe(texte, debut)
    if (p === "☐ ") return { retirer: 1, inserer: "☑", decalage: 0 }
    if (p === "☑ ") return { retirer: 1, inserer: "☐", decalage: 0 }
    if (p === "• ") return { retirer: 1, inserer: "☐", decalage: 0 }
    return { retirer: 0, inserer: "☐ ", decalage: 2 }
}
function actionPuce(texte, debut) {
    var p = prefixe(texte, debut)
    if (p === "• ") return { retirer: 2, inserer: "", decalage: -2 }
    if (p !== "") return { retirer: 1, inserer: "•", decalage: 0 }
    return { retirer: 0, inserer: "• ", decalage: 2 }
}
// Entrée sur une ligne de liste : continuer la liste, ou la terminer si la ligne est vide
function actionEntree(texte, pos) {
    var d = debutLigne(texte, pos), p = prefixe(texte, d)
    if (p === "") return null
    if (ligne(texte, d).replace(/\s+$/, "") === p.trim()) return { finir: true, debut: d }
    return { finir: false, suite: p === "• " ? "• " : "☐ " }
}
