#!/bin/bash
# =====================================================================
#  installer-kvantum.sh — installe le style néon des fenêtres (Kvantum Dark + Jour) pour tous les comptes
#  (lancé en administrateur par le paquet cyberpunkos ou la fabrication de l'ISO)
#  Le Suivi du thème bascule ensuite tout seul CyberpunkOS ↔ CyberpunkOS-Jour, sauf choix perso.
# =====================================================================
K="$(cd "$(dirname "$0")" && pwd)"
ls /usr/lib/*/qt6/plugins/styles/libkvantum.so >/dev/null 2>&1 || { echo "  --      Kvantum absent : style néon des fenêtres ignoré"; exit 0; }
[ -f "$K/themes/CyberpunkOS/CyberpunkOS.svg" ] || python3 "$K/generer-kvantum.py" "$K/themes" || exit 0
mkdir -p /usr/share/Kvantum /etc/xdg/Kvantum
for t in CyberpunkOS CyberpunkOS-Jour; do
  [ -d "$K/themes/$t" ] || continue
  rm -rf "/usr/share/Kvantum/$t"; cp -a "$K/themes/$t" /usr/share/Kvantum/
done
kwriteconfig6 --file /etc/xdg/Kvantum/kvantum.kvconfig --group General --key theme CyberpunkOS
kwriteconfig6 --file /etc/xdg/kdeglobals --group KDE --key widgetStyle kvantum
echo "  OK      style néon des fenêtres (Kvantum CyberpunkOS + Jour)"
