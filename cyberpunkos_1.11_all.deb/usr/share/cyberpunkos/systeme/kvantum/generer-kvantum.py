#!/usr/bin/env python3
# =====================================================================
#  generer-kvantum.py — fabrique les thèmes Kvantum CyberpunkOS (Dark) et CyberpunkOS-Jour
#  à partir d'un thème Kvantum plat déjà installé (on garde sa forme, on refait toutes les couleurs).
#
#  Usage : python3 generer-kvantum.py <dossier de sortie>
#  Règles (croquis validés) : fond nuit, contours cyan, survol cyan la nuit / framboise le jour,
#  appui / coché / sélection / progression en jaune, désactivé en gris.
#  11/11 : les dessins partagés (<use>, ex. champ actif = bouton appuyé) sont recopiés
#          pour que chaque élément ait sa propre couleur (champ de recherche plus jaune) ;
#          survol des menus en cyan (nuit) / framboise (jour), jamais jaune
# =====================================================================
import os, re, sys, shutil, copy, configparser
import xml.etree.ElementTree as ET

SOURCES = ['/usr/share/Kvantum', os.path.expanduser('~/.config/Kvantum')]
BASES = ['KvFlat', 'KvSimplicity', 'KvGnome', 'KvArc', 'KvAdapta', 'KvCurves', 'KvAmbiance']

PALETTES = {
  'CyberpunkOS': dict(          # nuit
    fond='#07080f', panneau='#0b0d18', champ='#0b0d18', alt='#10131f', texte='#e6e8f2', doux='#9aa0bd',
    contour='#1f6f7a', neon='#00f0ff', survol='#00f0ff', survol_fond='#0a2a33', appui='#f5e400',
    appui_texte='#07080f', gris='#3a3f55', gris_texte='#5a5f7a', ombre='#000000', lien='#00f0ff',
    lien_vu='#ff2bd6', bulle='#07080f', bulle_texte='#f5e400'),
  'CyberpunkOS-Jour': dict(     # jour
    fond='#eceef4', panneau='#fafbff', champ='#ffffff', alt='#f2f4fa', texte='#10121c', doux='#5a5f7a',
    contour='#7fc4d1', neon='#0089a3', survol='#c4007f', survol_fond='#fbe3f1', appui='#f5e400',
    appui_texte='#10121c', gris='#c8cbd8', gris_texte='#9aa0bd', ombre='#7a7f99', lien='#0089a3',
    lien_vu='#c4007f', bulle='#10121c', bulle_texte='#f5e400'),
}

COTES = ('-topleft', '-topright', '-bottomleft', '-bottomright', '-top', '-bottom', '-left', '-right')
COUL = re.compile(r'#[0-9a-fA-F]{6}\b|#[0-9a-fA-F]{3}\b')

def role(id_, p):
    """couleur voulue pour un élément SVG d'après son identifiant Kvantum"""
    i = id_.lower()
    cadre = i.endswith(COTES) or '-shadow' in i or i.startswith('shadow')
    if 'shadow' in i: return p['ombre']
    if 'disabled' in i: return p['gris'] if cadre else p['alt']
    # indicateurs (flèches, coches, croix d'onglet, poignées) : couleur du texte / néon
    if any(k in i for k in ('arrow', 'mdi', 'tab-close', 'close', 'grip', 'handle-', 'expand', 'collapse')):
        if 'focused' in i or 'hover' in i: return p['survol']
        if 'pressed' in i or 'toggled' in i: return p['appui']
        return p['neon']
    if any(k in i for k in ('checkbox', 'radio')):
        if 'checked' in i or 'tristate' in i or 'on-' in i: return p['appui']
        if 'focused' in i: return p['survol']
        return p['contour'] if cadre else p['champ']
    if 'progress' in i or 'slider-cursor' in i or 'scrollbarslider' in i and 'focused' in i:
        if 'pattern' in i or 'progress-normal' in i or 'progress-' in i: return p['appui'] if not cadre else p['appui']
    # lignes de menu et de barre de menus : le survol est TOUJOURS cyan (nuit) / framboise (jour)
    if i.startswith(('menuitem', 'menubaritem')) and 'normal' not in i:
        return p['survol'] if cadre else p['survol_fond']
    if 'pressed' in i or 'toggled' in i or 'selected' in i or 'checked' in i:
        return p['appui']
    if 'focused' in i or 'hover' in i:
        return p['survol'] if cadre else p['survol_fond']
    if 'focus' in i:                       # anneau de focus clavier
        return p['neon']
    if any(k in i for k in ('lineedit', 'combo', 'spin', 'itemview', 'textedit')):
        return p['contour'] if cadre else p['champ']
    if any(k in i for k in ('menu', 'tooltip', 'window', 'dialog', 'dock', 'toolbar')):
        return p['contour'] if cadre else p['panneau']
    return p['contour'] if cadre else p['panneau']

NS = {'': 'http://www.w3.org/2000/svg', 'xlink': 'http://www.w3.org/1999/xlink',
      'inkscape': 'http://www.inkscape.org/namespaces/inkscape', 'sodipodi': 'http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd',
      'rdf': 'http://www.w3.org/1999/02/22-rdf-syntax-ns#', 'cc': 'http://creativecommons.org/ns#', 'dc': 'http://purl.org/dc/elements/1.1/'}
for _k, _v in NS.items(): ET.register_namespace(_k, _v)
SVG, XL = '{%s}' % NS[''], '{%s}' % NS['xlink']

def deplier_use(texte):
    """remplace chaque <use> (dessin partagé, ex. lineedit-focused = button-pressed) par une vraie copie,
    pour que chaque élément puisse avoir SA couleur"""
    try:
        racine = ET.fromstring(texte.encode('utf-8'))
    except ET.ParseError:
        return texte
    for _ in range(4):                                   # 4 passes : <use> qui pointent vers d'autres <use>
        ids = {e.get('id'): e for e in racine.iter() if e.get('id')}
        parents = {c: pa for pa in racine.iter() for c in pa}
        uses = [u for u in racine.iter(SVG + 'use')]
        if not uses: break
        for u in uses:
            ref = (u.get(XL + 'href') or u.get('href') or '').lstrip('#')
            cible = ids.get(ref)
            if cible is None or u not in parents: continue
            cp = copy.deepcopy(cible)
            for e in cp.iter():
                if 'id' in e.attrib: del e.attrib['id']
            g = ET.Element(SVG + 'g')
            if u.get('id'): g.set('id', u.get('id'))
            tr = u.get('transform', '')
            x, y = u.get('x', '0'), u.get('y', '0')
            if x not in ('0', '') or y not in ('0', ''): tr = (tr + ' translate(%s,%s)' % (x, y)).strip()
            if tr: g.set('transform', tr)
            if cp.tag == SVG + 'symbol': cp.tag = SVG + 'g'
            g.append(cp)
            pa = parents[u]; i = list(pa).index(u); pa.remove(u); pa.insert(i, g)
    return ET.tostring(racine, encoding='unicode')

def recolorer_svg(texte, p):
    texte = deplier_use(texte)
    # découpe par élément <... id="..." ...> et recolore les couleurs dans chaque élément, ses enfants compris
    sortie, pos, pile = [], 0, []
    for m in re.finditer(r'<(/?)([a-zA-Z:]+)([^>]*?)(/?)>', texte):
        avant = texte[pos:m.start()]
        sortie.append(avant)
        ferme, tag, attrs, auto = m.group(1), m.group(2), m.group(3), m.group(4)
        if ferme:
            if pile: pile.pop()
            sortie.append(m.group(0))
        else:
            idm = re.search(r'\bid="([^"]+)"', attrs)
            courant = pile[-1] if pile else None
            if idm and '-' in idm.group(1): courant = idm.group(1)
            if courant and tag not in ('svg', 'defs', 'linearGradient', 'radialGradient', 'stop'):
                c = role(courant, p)
                attrs = COUL.sub(c, attrs)
                attrs = re.sub(r'url\(#[^)]+\)', c, attrs)   # dégradés → couleur plate (style néon)
            elif courant and tag == 'stop':
                attrs = COUL.sub(role(courant, p), attrs)
            sortie.append('<' + tag + attrs + auto + '>')
            if not auto: pile.append(courant)
        pos = m.end()
    sortie.append(texte[pos:])
    return ''.join(sortie)

def couleurs_kvconfig(p):
    return {
      'window.color': p['fond'], 'base.color': p['champ'], 'alt.base.color': p['alt'],
      'button.color': p['panneau'], 'light.color': p['alt'], 'mid.light.color': p['alt'],
      'dark.color': p['fond'], 'mid.color': p['contour'], 'shadow.color': p['ombre'],
      'highlight.color': p['appui'], 'inactive.highlight.color': p['appui'],
      'text.color': p['texte'], 'window.text.color': p['texte'], 'button.text.color': p['texte'],
      'disabled.text.color': p['gris_texte'], 'tooltip.text.color': p['bulle_texte'],
      'tooltip.base.color': p['bulle'], 'highlight.text.color': p['appui_texte'],
      'link.color': p['lien'], 'link.visited.color': p['lien_vu'],
      'progress.indicator.text.color': p['appui_texte'], 'placeholder.text.color': p['doux'],
    }

def trouver_base():
    for b in BASES:
        for s in SOURCES:
            d = os.path.join(s, b)
            if os.path.isfile(os.path.join(d, b + '.svg')) and os.path.isfile(os.path.join(d, b + '.kvconfig')):
                return b, d
    return None, None

def main():
    out = sys.argv[1] if len(sys.argv) > 1 else '.'
    base, dossier = trouver_base()
    if not base:
        sys.exit("  !!      aucun thème Kvantum de base trouvé : sudo apt install qt6-style-kvantum")
    svg = open(os.path.join(dossier, base + '.svg'), encoding='utf-8').read()
    for nom, p in PALETTES.items():
        d = os.path.join(out, nom); shutil.rmtree(d, ignore_errors=True); os.makedirs(d)
        open(os.path.join(d, nom + '.svg'), 'w', encoding='utf-8').write(recolorer_svg(svg, p))
        cfg = configparser.RawConfigParser(strict=False, interpolation=None); cfg.optionxform = str
        cfg.read(os.path.join(dossier, base + '.kvconfig'), encoding='utf-8')
        if not cfg.has_section('%General'): cfg.add_section('%General')
        g = cfg['%General']
        g['author'] = 'CyberpunkOS'; g['comment'] = nom + ' — généré depuis ' + base
        g['translucent_windows'] = 'false'; g['blurring'] = 'false'; g['popup_blurring'] = 'false'
        g['composite'] = 'true'
        if not cfg.has_section('GeneralColors'): cfg.add_section('GeneralColors')
        for k, v in couleurs_kvconfig(p).items(): cfg['GeneralColors'][k] = v
        # textes : survol en couleur néon, texte foncé quand pressé (fond jaune) — sauf menus (survol cyan)
        for sec in cfg.sections():
            s = cfg[sec]
            menu = sec.lower().startswith(('menuitem', 'menubaritem'))
            if 'text.normal.color' in s: s['text.normal.color'] = p['texte']
            if 'text.focus.color' in s: s['text.focus.color'] = p['survol']
            if 'text.press.color' in s: s['text.press.color'] = p['survol'] if menu else p['appui_texte']
            if 'text.toggle.color' in s: s['text.toggle.color'] = p['survol'] if menu else p['appui_texte']
        with open(os.path.join(d, nom + '.kvconfig'), 'w', encoding='utf-8') as f: cfg.write(f, space_around_delimiters=False)
        print(f"  OK      thème Kvantum {nom} (base : {base})")

if __name__ == '__main__':
    main()
