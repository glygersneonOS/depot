#!/bin/bash
# =====================================================================
#  kvantum-cyberpunkos.sh — style néon des fenêtres (boutons, champs, barres de progression,
#  survol cyan la nuit / framboise le jour) avec Kvantum
#
#  Usage (dans l'atelier, SANS sudo) :
#    bash kvantum-cyberpunkos.sh            génère + applique à ton compte (essai)
#    bash kvantum-cyberpunkos.sh --jour     essai de la version Jour
#    bash kvantum-cyberpunkos.sh --annuler  revient au style d'origine (Breeze)
#  Les applis ouvertes doivent être relancées pour prendre le nouveau style.
# =====================================================================
set -eu
[ "$(id -u)" != 0 ] || { echo "Lance-le SANS sudo : bash kvantum-cyberpunkos.sh"; exit 1; }
K="$(cd "$(dirname "$0")" && pwd)"            # systeme/kvantum
ok() { echo "  OK      $*"; }

if [ "${1:-}" = "--annuler" ]; then
  kwriteconfig6 --file kdeglobals --group KDE --key widgetStyle Breeze
  ok "style d'origine (Breeze) remis — relance les applis ouvertes"
  exit 0
fi
command -v kvantummanager >/dev/null || { echo "  !!      Kvantum manque : sudo apt install qt6-style-kvantum"; exit 1; }

python3 "$K/generer-kvantum.py" "$K/themes"
mkdir -p ~/.config/Kvantum
for t in CyberpunkOS CyberpunkOS-Jour; do rm -rf ~/.config/Kvantum/$t; cp -a "$K/themes/$t" ~/.config/Kvantum/; done
T=CyberpunkOS; [ "${1:-}" = "--jour" ] && T=CyberpunkOS-Jour
kwriteconfig6 --file Kvantum/kvantum.kvconfig --group General --key theme "$T"
kwriteconfig6 --file kdeglobals --group KDE --key widgetStyle kvantum
ok "style Kvantum $T appliqué"
echo
echo "  Ouvre ou relance le CyberStore, le Centre des fichiers, le Centre de contrôle… pour voir le résultat."
echo "  Pour revenir en arrière : bash kvantum-cyberpunkos.sh --annuler"
