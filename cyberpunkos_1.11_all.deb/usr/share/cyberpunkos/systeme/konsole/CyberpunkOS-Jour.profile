[Appearance]
ColorScheme=CyberpunkOS-Jour
Font=Noto Sans Mono,12

[General]
Name=CyberpunkOS Jour
Parent=FALLBACK/

