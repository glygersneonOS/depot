[Appearance]
ColorScheme=CyberpunkOS
Font=Noto Sans Mono,12

[General]
Name=CyberpunkOS
Parent=FALLBACK/
