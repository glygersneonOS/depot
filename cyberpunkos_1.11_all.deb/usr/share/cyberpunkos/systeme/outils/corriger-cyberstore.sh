#!/bin/bash
# =====================================================================
#  corriger-cyberstore.sh — le CyberStore ouvre DIRECTEMENT Discover
#  (et plus le petit lanceur « Manage Software » de Kubuntu, qui est masqué)
#  Lancé en administrateur par le paquet cyberpunkos (après l'installateur).
# =====================================================================
O=/usr/local/share/applications; A=/usr/share/applications
mkdir -p "$O"
D="$A/org.kde.discover.desktop"
if [ -f "$D" ] && command -v plasma-discover >/dev/null; then
  awk '
    /^\[/ { entree = ($0 == "[Desktop Entry]") ; print; if (entree) { print "Name=CyberStore"; print "Comment=Installer et mettre à jour des applis" }; next }
    entree && /^(Name|GenericName|Comment|NoDisplay|Hidden)(\[[^]]*\])?=/ { next }
    entree && /^Exec=/    { print "Exec=plasma-discover %F"; next }
    entree && /^TryExec=/ { print "TryExec=plasma-discover"; next }
    { print }' "$D" > "$O/org.kde.discover.desktop"
  echo "  OK      CyberStore = Discover"
fi
# petit lanceur Kubuntu « Manage Software » : masqué
for f in "$A"/*.desktop; do
  [ "$f" = "$D" ] && continue
  grep -qiE '^Name=.*Manage Software|^Exec=.*manage-software' "$f" 2>/dev/null || continue
  awk '/^\[/ { entree = ($0 == "[Desktop Entry]"); print; if (entree) print "NoDisplay=true"; next }
       entree && /^(NoDisplay|Hidden)=/ { next } { print }' "$f" > "$O/$(basename "$f")"
  echo "  OK      lanceur Kubuntu « $(basename "$f" .desktop) » masqué"
done
command -v update-desktop-database >/dev/null && update-desktop-database "$O" 2>/dev/null
exit 0
