#!/bin/bash
# =====================================================================
#  masquer-applis.sh — masque du menu (SANS les désinstaller) les applis Kubuntu
#  remplacées par une appli CyberpunkOS. Lancé par la mise à jour (en administrateur).
#
#  Chacun son thème : pour faire revenir une appli Kubuntu dans le menu,
#    sudo rm /usr/local/share/applications/<fichier>.desktop
# =====================================================================
set -u
D=/usr/local/share/applications
mkdir -p "$D"

# appli Kubuntu remplacée → appli CyberpunkOS qui la remplace
REMPLACEES="
org.kde.kcalc.desktop cyberpunkos-calculatrice
org.kde.knotes.desktop cyberpunkos-notes
"

echo "$REMPLACEES" | while read -r F NOTRE; do
  [ -n "${F:-}" ] || continue
  SRC=/usr/share/applications/$F
  [ -f "$SRC" ] || continue                                     # appli Kubuntu pas installée
  command -v "$NOTRE" >/dev/null 2>&1 || continue               # la nôtre n'est pas là : on ne cache rien
  awk '
    /^\[/ { if (sec && !fait) print "NoDisplay=true"; sec = ($0 == "[Desktop Entry]"); fait = 0 }
    sec && /^NoDisplay=/ { print "NoDisplay=true"; fait = 1; next }
    { print }
    END { if (sec && !fait) print "NoDisplay=true" }
  ' "$SRC" > "$D/$F"
  echo "masquée : $F (remplacée par $NOTRE)"
done
exit 0
