#!/bin/bash
# =====================================================================
#  installer-cyberpunkos.sh — transforme un Kubuntu (26.04, Plasma 6) en CyberpunkOS
#
#  Deux façons de l'utiliser :
#    bash installer-cyberpunkos.sh            → sur un PC/une VM : système + ton compte
#    bash installer-cyberpunkos.sh --systeme  → pour fabriquer l'ISO : système + réglages
#                                               par défaut de tout futur compte, sans session
#  Peut être relancé sans risque (par ex. après une mise à jour de Kubuntu).
#
#  V.1.1 : rebond de l'icône désactivé, raccourcis Kubuntu retirés du bureau
#  V.1.2 : menu de démarrage (GRUB) et écran de chargement (Plymouth)
#  V.1.3 : nom du système, applis renommées, thème global, collection de fonds
#  V.1.4 : mode --systeme (CyberpunkOS par défaut pour tout nouveau compte, prêt pour l'ISO)
#  V.1.5 : Centre de bienvenue KDE masqué, épingles de la barre des tâches CyberpunkOS
#  V.1.6 : fond d'écran animé « CyberpunkOS Néon » (dégradés + lignes roses, avec aperçu)
#  V.1.7 : CyberpunkOS Jour (thème clair : couleurs, barre de titre, terminal) + bascule Jour/Dark
#  V.1.8 : icônes Jour (néons foncés + petites icônes foncées) + « Suivi du thème » :
#          un changement de thème global applique tout, sauf les choix perso
# =====================================================================
set -u
S="$(cd "$(dirname "$0")" && pwd)"
V="$(cat "$S/VERSION" 2>/dev/null || echo 1)"
MODE=utilisateur; [ "${1:-}" = "--systeme" ] && MODE=systeme
SUDO=sudo; [ "$(id -u)" = 0 ] && SUDO=""
U=/usr/share
BG=$U/backgrounds/cyberpunkos
X=/etc/xdg
[ -d "$S/icons/CyberpunkOS" ] || { echo "Dossier incomplet : lance d'abord collecter.sh"; exit 1; }
echo "======================================"
echo "   Installation de CyberpunkOS V.$V  (mode $MODE)"
echo "======================================"
kw() { $SUDO kwriteconfig6 --file "$X/$1" --group "$2" --key "$3" "$4"; }   # réglage par défaut (tous les comptes)

# ---------------------------------------------------------------- 1/6
echo "-- 1/6 Logiciels nécessaires (peut prendre quelques minutes)"
$SUDO apt install -y papirus-icon-theme python3 >/dev/null 2>&1 && echo "  OK      icônes Papirus"
if [ "$MODE" = utilisateur ]; then
  command -v chromium >/dev/null || { $SUDO snap install chromium >/dev/null 2>&1 && echo "  OK      Chromium (pour Ma paie)"; }
fi

# ---------------------------------------------------------------- 2/6
echo "-- 2/6 Fichiers du système"
$SUDO mkdir -p $U/color-schemes $U/icons/hicolor/scalable/apps $U/icons/default $U/aurorae/themes $U/plasma/look-and-feel \
               $U/plasma/wallpapers $U/sounds $U/konsole $U/wallpapers $BG $U/pixmaps $U/applications /etc/sddm.conf.d $X \
               /etc/xdg/autostart /etc/skel/.config/autostart /usr/local/bin

$SUDO cp -f "$S"/color-schemes/*.colors $U/color-schemes/                                   && echo "  OK      palettes de couleurs (Dark, Cyan, Jour)"
$SUDO rm -rf $U/icons/CyberpunkOS && $SUDO cp -a "$S/icons/CyberpunkOS" $U/icons/             && echo "  OK      icônes"
# icônes Jour : les mêmes, avec les néons foncés (lisibles sur fond clair) et les petites icônes foncées (Papirus)
J=$U/icons/CyberpunkOS-Jour
$SUDO rm -rf "$J" && $SUDO cp -a $U/icons/CyberpunkOS "$J"
$SUDO find "$J" -name '*.svg' -exec sed -i -e 's/#00f0ff/#0089a3/gI' -e 's/#ff2bd6/#c4007f/gI' -e 's/#f5e400/#c29e00/gI' {} +
$SUDO sed -i -e 's/^Name=.*/Name=CyberpunkOS Jour/' -e 's/^Comment=.*/Comment=Icônes CyberpunkOS pour le thème clair/' \
             -e 's/^Inherits=.*/Inherits=Papirus,breeze,hicolor/' "$J/index.theme"
echo "  OK      icônes Jour"
$SUDO rm -rf $U/icons/CyberpunkOS-Cursors && $SUDO tar xzf "$S/icons/CyberpunkOS-Cursors.tar.gz" -C $U/icons/ && echo "  OK      curseurs"
for a in "$S"/aurorae/*; do
  [ -d "$a" ] || continue
  $SUDO rm -rf "$U/aurorae/themes/$(basename "$a")" && $SUDO cp -a "$a" $U/aurorae/themes/
done
echo "  OK      barres de titre (Dark + Jour)"
for p in "$S"/plasma/*; do
  [ -d "$p" ] || continue
  $SUDO rm -rf "$U/plasma/look-and-feel/$(basename "$p")" && $SUDO cp -a "$p" $U/plasma/look-and-feel/
done
# le thème Jour reprend les aperçus du thème Dark
JL=$U/plasma/look-and-feel/org.cyberpunkos.jour.desktop/contents
DL=$U/plasma/look-and-feel/org.cyberpunkos.desktop/contents
[ -d "$JL" ] && [ -d "$DL/previews" ] && [ ! -d "$JL/previews" ] && $SUDO cp -a "$DL/previews" "$JL/"
echo "  OK      thèmes globaux CyberpunkOS + CyberpunkOS Jour"
$SUDO rm -rf $U/sounds/CyberpunkOS && $SUDO cp -a "$S/sounds/CyberpunkOS" $U/sounds/          && echo "  OK      sons"
$SUDO cp -f "$S"/konsole/* $U/konsole/                                                       && echo "  OK      terminal (Dark + Jour)"
$SUDO cp -f "$S"/wallpapers/* $BG/
for w in "$S"/wallpapers-collection/*; do
  [ -d "$w" ] || continue
  $SUDO rm -rf "$U/wallpapers/$(basename "$w")" && $SUDO cp -a "$w" $U/wallpapers/
done
echo "  OK      collection de fonds d'écran"
for p in "$S"/wallpaper-plugin/*; do
  [ -d "$p" ] || continue
  $SUDO rm -rf "$U/plasma/wallpapers/$(basename "$p")" && $SUDO cp -a "$p" $U/plasma/wallpapers/
  echo "  OK      fond animé $(basename "$p")"
done
if [ -f "$S/outils/cyberpunkos-suivi-theme" ]; then
  $SUDO install -m 755 "$S/outils/cyberpunkos-suivi-theme" /usr/local/bin/cyberpunkos-suivi-theme
  $SUDO install -m 644 "$S/outils/cyberpunkos-suivi-theme.desktop" /etc/xdg/autostart/cyberpunkos-suivi-theme.desktop
  echo "  OK      Suivi du thème (Dark ↔ Jour partout, sauf choix perso)"
fi
$SUDO cp -f "$S"/logo/* $U/pixmaps/                                                          && echo "  OK      logo"
$SUDO cp -f "$S/icons/ma-paie.svg" $U/icons/hicolor/scalable/apps/ma-paie.svg
URL="$(grep -o 'https://[^ ]*' "$S/applications/ma-paie.desktop" | head -1)"
sed -e 's|^Icon=.*|Icon=ma-paie|' -e "s|^Exec=.*|Exec=sh -c \"chromium --app=$URL \|\| firefox $URL\"|" "$S/applications/ma-paie.desktop" \
  | $SUDO tee $U/applications/ma-paie.desktop >/dev/null && echo "  OK      appli Ma paie"

$SUDO mkdir -p $U/plasma/look-and-feel-masques $U/wallpapers-masques
for d in $(find $U/plasma/look-and-feel -maxdepth 1 -iname '*kubuntu*'); do $SUDO mv "$d" $U/plasma/look-and-feel-masques/; done
for d in $U/wallpapers/*; do
  [ -e "$d" ] || continue
  case "$(basename "$d")" in CyberpunkOS*) continue ;; esac
  $SUDO rm -rf "$U/wallpapers-masques/$(basename "$d")"; $SUDO mv "$d" $U/wallpapers-masques/
done
echo "  OK      thèmes et fonds Kubuntu masqués"

FOND=$BG/ville-eliott.png
[ -f "$FOND" ] || FOND=$BG/cyberpunkos.svg
$SUDO cp -f "$FOND" $U/sddm/themes/breeze/
printf '[General]\nbackground=%s\ntype=image\n' "$U/sddm/themes/breeze/$(basename "$FOND")" | $SUDO tee $U/sddm/themes/breeze/theme.conf.user >/dev/null
printf '[Theme]\nCurrent=breeze\n' | $SUDO tee /etc/sddm.conf.d/cyberpunkos.conf >/dev/null && echo "  OK      écran de connexion"
printf '[General]\nName=CyberpunkOS\nVersion=V.%s\nLogoPath=%s/pixmaps/cyberpunkos-logo.png\nWebsite=https://kubuntu.org\n' "$V" "$U" | $SUDO tee $X/kcm-about-distrorc >/dev/null && echo "  OK      « À propos de ce système »"
$SUDO gtk-update-icon-cache -f $U/icons/hicolor >/dev/null 2>&1

for d in /etc/skel/Desktop /etc/skel/Bureau; do
  [ -d "$d" ] || continue
  for f in "$d"/*.desktop; do [ -e "$f" ] && grep -qi kubuntu "$f" && $SUDO rm -f "$f"; done
done

# ---------------------------------------------------------------- 3/6
echo "-- 3/6 Démarrage du PC (menu + écran de chargement) — 1 à 2 minutes"
if [ -d "$S/boot/grub-cyberpunkos" ]; then
  $SUDO mkdir -p /boot/grub/themes /etc/default/grub.d
  $SUDO rm -rf /boot/grub/themes/cyberpunkos && $SUDO cp -a "$S/boot/grub-cyberpunkos" /boot/grub/themes/cyberpunkos
  $SUDO cp -f "$S/boot/99-cyberpunkos.cfg" /etc/default/grub.d/99-cyberpunkos.cfg
  for t in cyberpunkos cyberpunkos-text; do
    $SUDO rm -rf $U/plymouth/themes/$t && $SUDO cp -a "$S/boot/plymouth-$t" $U/plymouth/themes/$t
  done
  $SUDO update-alternatives --install $U/plymouth/themes/default.plymouth default.plymouth $U/plymouth/themes/cyberpunkos/cyberpunkos.plymouth 300 >/dev/null
  $SUDO update-alternatives --set default.plymouth $U/plymouth/themes/cyberpunkos/cyberpunkos.plymouth >/dev/null
  $SUDO update-alternatives --install $U/plymouth/themes/text.plymouth text.plymouth $U/plymouth/themes/cyberpunkos-text/cyberpunkos-text.plymouth 300 >/dev/null
  $SUDO update-alternatives --set text.plymouth $U/plymouth/themes/cyberpunkos-text/cyberpunkos-text.plymouth >/dev/null
  if [ "$MODE" = utilisateur ]; then
    $SUDO update-grub >/dev/null 2>&1          && echo "  OK      menu de démarrage"
    $SUDO update-initramfs -u >/dev/null 2>&1  && echo "  OK      écran de chargement"
  else
    $SUDO update-initramfs -u >/dev/null 2>&1  ; echo "  OK      menu + écran de chargement (appliqués à l'installation de l'OS)"
  fi
else
  echo "  --      pas de fichiers de démarrage dans ce dossier (étape ignorée)"
fi

# ---------------------------------------------------------------- 4/6
echo "-- 4/6 Identité du système"
for f in /usr/lib/os-release /etc/lsb-release /etc/issue /etc/issue.net; do
  dpkg-divert --list "$f" | grep -q cyberpunkos || $SUDO dpkg-divert --package cyberpunkos --local --rename --divert "$f.kubuntu" --add "$f" >/dev/null 2>&1
done
if [ ! -s /usr/lib/os-release.kubuntu ] || [ ! -s /etc/lsb-release.kubuntu ]; then
  $SUDO apt install --reinstall -y base-files >/dev/null 2>&1
fi
$SUDO sed -e "s/^PRETTY_NAME=.*/PRETTY_NAME=\"CyberpunkOS V.$V\"/" -e 's/^NAME=.*/NAME="CyberpunkOS"/' \
          -e "s/^VERSION=.*/VERSION=\"$V (base Kubuntu 26.04 LTS)\"/" -e '/^LOGO=/d' /usr/lib/os-release.kubuntu | $SUDO tee /usr/lib/os-release >/dev/null
echo 'LOGO=cyberpunkos-logo' | $SUDO tee -a /usr/lib/os-release >/dev/null
$SUDO sed -e "s/^DISTRIB_DESCRIPTION=.*/DISTRIB_DESCRIPTION=\"CyberpunkOS V.$V\"/" /etc/lsb-release.kubuntu | $SUDO tee /etc/lsb-release >/dev/null
printf 'CyberpunkOS V.%s \\n \\l\n\n' "$V" | $SUDO tee /etc/issue >/dev/null
printf 'CyberpunkOS V.%s\n' "$V" | $SUDO tee /etc/issue.net >/dev/null
echo "  OK      nom du système : $(grep ^PRETTY_NAME= /etc/os-release | cut -d'"' -f2)"

$SUDO python3 - << 'EOF'
import glob, os, re
O = '/usr/local/share/applications'; os.makedirs(O, exist_ok=True)
regles = [
 ('Konsole',                 'CyberTerminal',       'Terminal néon CyberpunkOS',             False),
 ('Dolphin',                 'Centre des fichiers', 'Explorer et ranger tes fichiers',       False),
 ('Discover',                'CyberStore',          'Installer et mettre à jour des applis', False),
 ('Manage Software',         'CyberStore',          'Installer et mettre à jour des applis', False),
 ('System Settings',         'Centre de contrôle',  'Tous les réglages de CyberpunkOS',      False),
 ('Configuration du système','Centre de contrôle',  'Tous les réglages de CyberpunkOS',      False),
 ('System Monitor',          'CyberMoniteur',       'Surveiller les applis et le PC',        False),
 ('Surveillance du système', 'CyberMoniteur',       'Surveiller les applis et le PC',        False),
 ('Restore desktop links',   None,                  None,                                    True),
]
def noms(txt):
    return [l.split('=', 1)[1].strip() for l in txt.splitlines() if re.match(r'^Name(\[fr[^\]]*\])?=', l)]
fichiers = glob.glob('/usr/share/applications/*.desktop') + glob.glob('/var/lib/snapd/desktop/applications/*.desktop')
n = 0
for f in fichiers:
    txt = open(f, encoding='utf-8', errors='ignore').read()
    if re.search(r'^Name[^=]*=.*Kubuntu', txt, re.M):
        out = re.sub(r'^((?:Name|GenericName|Comment)[^=]*=.*)$', lambda m: m.group(1).replace('Kubuntu', 'CyberpunkOS'), txt, flags=re.M)
        open(f'{O}/{os.path.basename(f)}', 'w', encoding='utf-8').write(out); n += 1
for chercher, nom, desc, cacher in regles:
    for f in fichiers:
        txt = open(f, encoding='utf-8', errors='ignore').read()
        if '[Desktop Entry]' not in txt or not any(x.lower() == chercher.lower() for x in noms(txt)): continue
        dest = f'{O}/{os.path.basename(f)}'
        if os.path.exists(dest): txt = open(dest, encoding='utf-8').read()
        tete, sep, reste = txt.partition('\n[Desktop Action')
        lignes = [l for l in tete.splitlines() if not re.match(r'^(Name|Comment)(\[[^\]]+\])?=|^NoDisplay=', l)]
        i = lignes.index('[Desktop Entry]') + 1
        ajout = [f'Name={nom}' if nom else f'Name={noms(txt)[0]}']
        if desc: ajout.append(f'Comment={desc}')
        if cacher: ajout.append('NoDisplay=true')
        lignes[i:i] = ajout
        open(dest, 'w', encoding='utf-8').write('\n'.join(lignes) + ('\n' + sep.lstrip('\n') + reste if sep else '\n')); n += 1
print(f'  OK      applis renommées ({n})')
EOF

# ---------------------------------------------------------------- 5/6
echo "-- 5/6 Réglages par défaut pour tous les comptes (et la session d'essai)"
grp=""
while IFS= read -r l; do
  case "$l" in
    \[*\]) grp="${l#[}"; grp="${grp%]}" ;;
    *=*)   [ -n "$grp" ] && [ "$grp" != General ] && kw kdeglobals "$grp" "${l%%=*}" "${l#*=}" ;;
  esac
done < "$S/color-schemes/CyberpunkOS.colors"
kw kdeglobals General ColorScheme CyberpunkOS
kw kdeglobals KDE     LookAndFeelPackage      org.cyberpunkos.desktop
kw kdeglobals KDE     DefaultDarkLookAndFeel  org.cyberpunkos.desktop
kw kdeglobals KDE     DefaultLightLookAndFeel org.cyberpunkos.jour.desktop
kw kdeglobals KDE     widgetStyle Breeze
kw kdeglobals Icons   Theme CyberpunkOS
kw kdeglobals Sounds  Theme CyberpunkOS
kw kdeglobals WM      activeFont "Noto Sans Mono,10,-1,5,700,0,0,0,0,0"
kw plasmarc   Theme   name default
kw plasmarc   Wallpapers defaultWallpaperTheme CyberpunkOS-Ville
kw kcminputrc Mouse   cursorTheme CyberpunkOS-Cursors
printf '[Icon Theme]\nInherits=CyberpunkOS-Cursors\n' | $SUDO tee $U/icons/default/index.theme >/dev/null
kw kwinrc org.kde.kdecoration2 library org.kde.kwin.aurorae
kw kwinrc org.kde.kdecoration2 theme   __aurorae__svg__CyberpunkOS
kw kwinrc Plugins startupfeedbackEnabled false
kw ksplashrc KSplash Engine KSplashQML
kw ksplashrc KSplash Theme  org.cyberpunkos.desktop
kw klaunchrc FeedbackStyle      BusyCursor false
kw klaunchrc BusyCursorSettings Bouncing   false
kw dolphinrc UiSettings ColorScheme CyberpunkOS-Cyan
kw konsolerc "Desktop Entry" DefaultProfile CyberpunkOS.profile
$SUDO kwriteconfig6 --file $X/kscreenlockerrc --group Greeter --group Wallpaper --group org.kde.image --group General --key Image "file://$FOND"
grep -q 'cyberpunkos-prompt' /etc/skel/.bashrc 2>/dev/null || $SUDO tee -a /etc/skel/.bashrc >/dev/null << 'EOB'
# cyberpunkos-prompt
PS1='\[\e[1;33m\]\u\[\e[0;36m\]@\h \[\e[1;35m\]\w \[\e[1;33m\]▸ \[\e[0m\]'
EOB
grep -qx snap /etc/skel/.hidden 2>/dev/null || echo snap | $SUDO tee -a /etc/skel/.hidden >/dev/null

# Centre de bienvenue KDE (Konqi) : ne s'ouvre plus tout seul pour les nouveaux comptes
PV="$(plasmashell --version 2>/dev/null | awk '{print $2}')"
[ -n "$PV" ] && kw plasma-welcomerc General LastSeenVersion "$PV"
kw plasma-welcomerc General ShowUpdatePage false
$SUDO kwriteconfig6 --file $X/kded6rc --group Module-plasma-welcome --key autoload false
for f in $X/autostart/*welcome*.desktop; do
  [ -e "$f" ] || continue
  printf '[Desktop Entry]\nType=Application\nName=Bienvenue\nHidden=true\n' | $SUDO tee "/etc/skel/.config/autostart/$(basename "$f")" >/dev/null
done

# scripts Plasma exécutés une fois à la première connexion de chaque compte
SH=$U/plasma/shells/org.kde.plasma.desktop/contents/updates
$SUDO mkdir -p "$SH"
$SUDO tee "$SH/cyberpunkos-menu.js" >/dev/null << 'EOJ'
var ps = panels();
for (var i in ps) { var w = ps[i].widgets();
  for (var j in w) { if (w[j].type == "org.kde.plasma.kickoff") {
    w[j].currentConfigGroup = ["General"];
    w[j].writeConfig("icon", "/usr/share/pixmaps/cyberpunkos-logo.png");
    w[j].writeConfig("menuLabel", "CYBERPUNK"); } } }
EOJ
# épingles : seulement si la barre a encore les épingles d'origine (ne touche pas une barre déjà personnalisée)
$SUDO tee "$SH/cyberpunkos-barre.js" >/dev/null << 'EOJ'
var ps = panels();
for (var i in ps) { var w = ps[i].widgets();
  for (var j in w) { if (w[j].type == "org.kde.plasma.icontasks" || w[j].type == "org.kde.plasma.taskmanager") {
    w[j].currentConfigGroup = ["General"];
    var l = String(w[j].readConfig("launchers", ""));
    if (l == "" || l.indexOf("welcome") >= 0) {
      w[j].writeConfig("launchers", ["applications:systemsettings.desktop", "applications:org.kde.discover.desktop",
        "applications:org.kde.dolphin.desktop", "applications:org.kde.konsole.desktop", "applications:firefox_firefox.desktop"]);
    } } } }
EOJ
echo "  OK      thème, couleurs, icônes, curseurs, barre de titre, sons, fond, menu, épingles, terminal"

# ---------------------------------------------------------------- 6/6
if [ "$MODE" = utilisateur ]; then
  echo "-- 6/6 Réglages de $USER"
  # on ne remet pas le thème si tu es déjà en CyberpunkOS (Dark ou Jour) : tes choix sont gardés
  if ! grep -q 'LookAndFeelPackage=org.cyberpunkos' ~/.config/kdeglobals 2>/dev/null; then
    plasma-apply-lookandfeel -a org.cyberpunkos.desktop  >/dev/null 2>&1
    plasma-apply-colorscheme CyberpunkOS                 >/dev/null 2>&1
  fi
  plasma-apply-desktoptheme default                    >/dev/null 2>&1
  plasma-apply-cursortheme CyberpunkOS-Cursors         >/dev/null 2>&1
  for c in "kdeglobals KDE DefaultDarkLookAndFeel org.cyberpunkos.desktop" "kdeglobals KDE DefaultLightLookAndFeel org.cyberpunkos.jour.desktop" \
           "kdeglobals Sounds Theme CyberpunkOS" \
           "ksplashrc KSplash Engine KSplashQML" "ksplashrc KSplash Theme org.cyberpunkos.desktop" \
           "klaunchrc FeedbackStyle BusyCursor false" "klaunchrc BusyCursorSettings Bouncing false" "kwinrc Plugins startupfeedbackEnabled false"; do
    set -- $c; kwriteconfig6 --file "$1" --group "${2//_/ }" --key "$3" "$4"
  done
  kwriteconfig6 --file kdeglobals --group WM --key activeFont "Noto Sans Mono,10,-1,5,700,0,0,0,0,0"
  # le fond n'est pas changé s'il est déjà personnalisé : seulement à la première installation
  if ! grep -q 'cyberpunkos' ~/.config/plasma-org.kde.plasma.desktop-appletsrc 2>/dev/null; then
    plasma-apply-wallpaperimage $U/wallpapers/CyberpunkOS-Ville >/dev/null 2>&1 || plasma-apply-wallpaperimage "$FOND" >/dev/null 2>&1
  fi
  kwriteconfig6 --file kscreenlockerrc --group Greeter --group Wallpaper --group org.kde.image --group General --key Image "file://$FOND"
  grep -q 'cyberpunkos-prompt' ~/.bashrc 2>/dev/null || printf "# cyberpunkos-prompt\nPS1='\\\\[\\\\e[1;33m\\\\]\\\\u\\\\[\\\\e[0;36m\\\\]@\\\\h \\\\[\\\\e[1;35m\\\\]\\\\w \\\\[\\\\e[1;33m\\\\]▸ \\\\[\\\\e[0m\\\\]'\n" >> ~/.bashrc
  grep -qx snap ~/.hidden 2>/dev/null || echo snap >> ~/.hidden
  BUREAU="$(xdg-user-dir DESKTOP 2>/dev/null || echo "$HOME/Desktop")"
  if [ -d "$BUREAU" ]; then
    for f in "$BUREAU"/*.desktop; do [ -e "$f" ] && grep -qi kubuntu "$f" && rm -f "$f"; done
  fi
  qdbus6 org.kde.plasmashell /PlasmaShell org.kde.PlasmaShell.evaluateScript "$(cat $SH/cyberpunkos-menu.js)" >/dev/null 2>&1
  kbuildsycoca6 >/dev/null 2>&1
  rm -f ~/.cache/icon-cache.kcache
  # (re)lance le Suivi du thème : il applique couleurs, icônes, barre de titre, explorateur et terminal
  pkill -f /usr/local/bin/cyberpunkos-suivi-theme 2>/dev/null
  [ -x /usr/local/bin/cyberpunkos-suivi-theme ] && (setsid /usr/local/bin/cyberpunkos-suivi-theme >/dev/null 2>&1 &)
  qdbus6 org.kde.KWin /KWin reconfigure >/dev/null 2>&1
  echo "  OK      ton compte est passé en CyberpunkOS"
else
  echo "-- 6/6 (mode système : pas de compte à régler)"
fi

echo "======================================"
echo "  CyberpunkOS V.$V installé (mode $MODE)."
[ "$MODE" = utilisateur ] && echo "  Redémarre le PC pour tout voir."
echo "======================================"
