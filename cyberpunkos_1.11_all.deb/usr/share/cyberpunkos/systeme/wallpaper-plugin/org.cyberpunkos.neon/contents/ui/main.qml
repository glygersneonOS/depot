// CyberpunkOS Néon — fond d'écran Plasma 6 (le dessin est dans Neon.qml)
import QtQuick
import org.kde.plasma.plasmoid

WallpaperItem {
    id: root

    Neon {
        anchors.fill: parent
        motif: root.configuration.Motif
        anime: root.configuration.Anime
        vitesse: root.configuration.Vitesse
    }
}
