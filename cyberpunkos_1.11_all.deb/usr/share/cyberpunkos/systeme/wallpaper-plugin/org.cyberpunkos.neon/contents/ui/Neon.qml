// CyberpunkOS Néon — le dessin du fond (utilisé par le bureau ET par l'aperçu des réglages)
// Motifs : 0 Néon, 1 Cyan, 2 Jaune, 3 Lignes roses, 4 Aurore, 5 Crépuscule, 6 Horizon
import QtQuick

Item {
    id: neon

    property int motif: 0
    property bool anime: true
    property real vitesse: 1

    // temps de l'animation (secondes × vitesse) ; revient à 0 en mode statique
    property real t: 0
    onAnimeChanged: if (!anime) t = 0

    Timer {
        interval: 33          // ~30 images/s : fluide et léger
        repeat: true
        running: neon.anime && neon.visible
        onTriggered: neon.t += 0.033 * Math.max(0.1, neon.vitesse)
    }

    // dégradés : angle « CSS » de départ, 4 couleurs, 4 positions
    // (index = numéro du motif ; le motif 3 « Lignes roses » n'est pas un dégradé)
    readonly property var degrades: [
        { a: 160, c: ["#1a0b2e", "#ff2bd6", "#00f0ff", "#00f0ff"], p: [0, 0.60, 1, 1] },       // 0 Néon
        { a: 160, c: ["#07080f", "#00f0ff", "#00f0ff", "#00f0ff"], p: [0, 0.70, 1, 1] },       // 1 Cyan
        { a: 160, c: ["#07080f", "#f5e400", "#f5e400", "#f5e400"], p: [0, 0.80, 1, 1] },       // 2 Jaune
        null,                                                                                  // 3 Lignes roses
        { a: 135, c: ["#06124a", "#087bff", "#8a00ff", "#ffe600"], p: [0, 0.333, 0.667, 1] },  // 4 Aurore (Eliott)
        { a: 180, c: ["#00134d", "#075cff", "#9b00ff", "#ffd900"], p: [0, 0.35, 0.68, 1] },    // 5 Crépuscule (Eliott)
        { a: 45,  c: ["#030a30", "#006eff", "#7300ff", "#ffdf00"], p: [0, 0.30, 0.60, 1] }     // 6 Horizon (Eliott)
    ]

    clip: true

    // fond nuit
    Rectangle {
        anchors.fill: parent
        color: "#07080f"
    }

    // ---------------------------------------------------------- dégradés
    Item {
        id: degrade
        anchors.fill: parent
        readonly property var d: (neon.motif >= 0 && neon.motif < neon.degrades.length) ? neon.degrades[neon.motif] : null
        visible: d !== null

        readonly property var g: d !== null ? d : neon.degrades[0]
        // angle qui oscille de ±25° (20 s par cycle)
        readonly property real angle: g.a + 25 * Math.sin(neon.t * 2 * Math.PI / 20)
        readonly property real rad: angle * Math.PI / 180
        // les couleurs du milieu « respirent » de ±0.10 (8 s par cycle)
        readonly property real souffle: 0.10 * Math.sin(neon.t * 2 * Math.PI / 8)
        function pos(i) {
            if (i === 0 || i === 3 || g.p[i] >= 1) return g.p[i];
            return Math.min(0.97, Math.max(0.03, g.p[i] + souffle));
        }

        Rectangle {
            anchors.centerIn: parent
            width: Math.sqrt(degrade.width * degrade.width + degrade.height * degrade.height) + 4
            height: Math.abs(degrade.width * Math.sin(degrade.rad)) + Math.abs(degrade.height * Math.cos(degrade.rad)) + 4
            rotation: degrade.angle - 180
            gradient: Gradient {
                GradientStop { position: degrade.pos(0); color: degrade.g.c[0] }
                GradientStop { position: degrade.pos(1); color: degrade.g.c[1] }
                GradientStop { position: degrade.pos(2); color: degrade.g.c[2] }
                GradientStop { position: degrade.pos(3); color: degrade.g.c[3] }
            }
        }
    }

    // ---------------------------------------------------------- lignes roses
    Item {
        id: lignes
        anchors.fill: parent
        visible: neon.motif === 3

        readonly property real pas: width / 16
        readonly property real ep: Math.max(1, Math.round(width / 640))
        // les lignes glissent vers la droite (1 espacement toutes les 6 s)
        readonly property real decalage: ((neon.t / 6) % 1) * pas

        Repeater {
            model: 19
            delegate: Item {
                id: ligne
                required property int index
                // une vague de lumière traverse les lignes (5 s par cycle)
                readonly property real force: 0.45 + 0.55 * Math.max(0, Math.cos(neon.t * 2 * Math.PI / 5 - (index - 1) * 0.5))
                x: (index - 1) * lignes.pas + lignes.decalage
                width: lignes.ep
                height: lignes.height

                Rectangle {          // halo
                    x: -lignes.ep * 3
                    width: lignes.ep * 7
                    height: parent.height
                    color: "#ff2bd6"
                    opacity: 0.18 * ligne.force
                }
                Rectangle {          // trait
                    width: lignes.ep
                    height: parent.height
                    color: "#ff2bd6"
                    opacity: ligne.force
                }
            }
        }
    }
}
