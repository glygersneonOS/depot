// Réglages du fond CyberpunkOS Néon (avec aperçu en direct)
import QtQuick
import QtQuick.Controls as QQC2
import QtQuick.Layouts
import org.kde.kirigami as Kirigami

Kirigami.FormLayout {
    id: root
    twinFormLayouts: parentLayout
    property alias formLayout: root

    property int cfg_Motif
    property int cfg_MotifDefault
    property bool cfg_Anime
    property bool cfg_AnimeDefault
    property real cfg_Vitesse
    property real cfg_VitesseDefault

    // taille de l'aperçu (format écran 16:9)
    readonly property int apercuL: Kirigami.Units.gridUnit * 24
    readonly property int apercuH: Math.round(apercuL * 9 / 16)

    QQC2.ComboBox {
        Kirigami.FormData.label: "Motif :"
        // l'ordre doit rester le même que dans Neon.qml
        model: ["Néon (magenta → cyan)", "Cyan", "Jaune", "Lignes roses",
                "Aurore (bleu → violet → jaune)", "Crépuscule (bleu → violet → or)", "Horizon (nuit → violet → jaune)"]
        currentIndex: root.cfg_Motif
        onActivated: root.cfg_Motif = currentIndex
    }

    QQC2.RadioButton {
        Kirigami.FormData.label: "Mode :"
        text: "Statique"
        checked: !root.cfg_Anime
        onToggled: if (checked) root.cfg_Anime = false
    }
    QQC2.RadioButton {
        text: "Dynamique (animé)"
        checked: root.cfg_Anime
        onToggled: if (checked) root.cfg_Anime = true
    }

    RowLayout {
        Kirigami.FormData.label: "Vitesse :"
        enabled: root.cfg_Anime
        QQC2.Slider {
            Layout.preferredWidth: Kirigami.Units.gridUnit * 12
            from: 0.25
            to: 3
            stepSize: 0.25
            value: root.cfg_Vitesse
            onMoved: root.cfg_Vitesse = value
        }
        QQC2.Label {
            text: "×" + Number(root.cfg_Vitesse).toFixed(2).replace(/\.?0+$/, "")
        }
    }

    // aperçu en direct : suit les réglages avant même de cliquer sur Appliquer
    Rectangle {
        Kirigami.FormData.label: "Aperçu :"
        implicitWidth: root.apercuL
        implicitHeight: root.apercuH
        Layout.preferredWidth: root.apercuL
        Layout.preferredHeight: root.apercuH
        Layout.minimumWidth: root.apercuL
        Layout.minimumHeight: root.apercuH
        Layout.topMargin: Kirigami.Units.largeSpacing
        color: "#07080f"
        border.color: "#00f0ff"
        border.width: 1

        Neon {
            anchors.fill: parent
            anchors.margins: 1
            motif: root.cfg_Motif
            anime: root.cfg_Anime
            vitesse: root.cfg_Vitesse
        }
    }
}
