import QtQuick

Rectangle {
    id: root
    color: "#07080f"
    property int stage

    Repeater {
        model: Math.ceil(root.height / 40)
        Rectangle { y: index * 40; width: root.width; height: 1; color: "#00f0ff"; opacity: 0.07 }
    }
    Repeater {
        model: Math.ceil(root.width / 40)
        Rectangle { x: index * 40; width: 1; height: root.height; color: "#00f0ff"; opacity: 0.07 }
    }

    Rectangle {
        width: root.width; height: 2; color: "#00f0ff"; opacity: 0.35
        NumberAnimation on y { from: 0; to: root.height; duration: 2500; loops: Animation.Infinite }
    }

    Column {
        anchors.centerIn: parent
        spacing: 26

        Item {
            width: title.width; height: title.height
            anchors.horizontalCenter: parent.horizontalCenter
            Text {
                anchors.centerIn: parent
                text: "CYBERPUNK OS"; color: "#f5e400"
                font.pixelSize: 96; font.bold: true; font.letterSpacing: 8
                scale: 1.05; opacity: 0.25
                SequentialAnimation on opacity {
                    loops: Animation.Infinite
                    NumberAnimation { to: 0.55; duration: 1500; easing.type: Easing.InOutSine }
                    NumberAnimation { to: 0.12; duration: 1500; easing.type: Easing.InOutSine }
                }
            }
            Text {
                id: title
                anchors.centerIn: parent
                text: "CYBERPUNK OS"; color: "#f5e400"
                font.pixelSize: 96; font.bold: true; font.letterSpacing: 8
            }
        }

        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: "// INITIALISATION DU SYSTÈME"; color: "#00f0ff"
            font.family: "Noto Sans Mono"; font.pixelSize: 20; font.letterSpacing: 4
        }

        Item {
            width: 520; height: 14
            anchors.horizontalCenter: parent.horizontalCenter
            Rectangle { anchors.fill: parent; color: "#1a1d2e"; border.color: "#2a2f48"; border.width: 1 }
            Rectangle {
                height: parent.height; color: "#f5e400"
                width: parent.width * Math.min(root.stage, 6) / 6
                Behavior on width { NumberAnimation { duration: 600; easing.type: Easing.OutCubic } }
            }
        }

        Column {
            anchors.horizontalCenter: parent.horizontalCenter
            spacing: 6
            Repeater {
                model: ["> NOYAU", "> AFFICHAGE", "> RÉSEAU", "> BUREAU", "> NÉONS", "> CONNEXION"]
                Row {
                    opacity: index < root.stage ? 1 : 0.2
                    Behavior on opacity { NumberAnimation { duration: 400 } }
                    Text { text: modelData; width: 440; color: "#e6e8f2"; font.family: "Noto Sans Mono"; font.pixelSize: 16 }
                    Text {
                        text: index < root.stage ? "OK" : "..."
                        color: index < root.stage ? "#00f0ff" : "#8a90a8"
                        font.family: "Noto Sans Mono"; font.pixelSize: 16; font.bold: true
                    }
                }
            }
        }
    }

    Rectangle { x: 40; y: 40; width: 100; height: 3; color: "#00f0ff" }
    Rectangle { x: 40; y: 40; width: 3; height: 100; color: "#00f0ff" }
    Rectangle { x: root.width - 140; y: 40; width: 100; height: 3; color: "#00f0ff" }
    Rectangle { x: root.width - 43; y: 40; width: 3; height: 100; color: "#00f0ff" }
    Rectangle { x: 40; y: root.height - 43; width: 100; height: 3; color: "#ff2bd6" }
    Rectangle { x: 40; y: root.height - 140; width: 3; height: 100; color: "#ff2bd6" }
    Rectangle { x: root.width - 140; y: root.height - 43; width: 100; height: 3; color: "#ff2bd6" }
    Rectangle { x: root.width - 43; y: root.height - 140; width: 3; height: 100; color: "#ff2bd6" }

    Text {
        anchors.right: parent.right; anchors.bottom: parent.bottom
        anchors.rightMargin: 60; anchors.bottomMargin: 60
        text: "CYBERPUNKOS · V.1"; color: "#8a90a8"
        font.family: "Noto Sans Mono"; font.pixelSize: 16
    }
}
