// =====================================================================
//  Fenêtre « Quoi de neuf ? » de CyberpunkOS (croquis validé)
//  Lancée par cyberpunkos-nouveautes :  qml Nouveautes.qml -- <dispo|installee> <version> <version installée> <fichier>
//  Fichier des nouveautés : une ligne par nouveauté « TYPE|texte » (NOUVEAU, FONDS, CORRIGÉ, AMÉLIORÉ…)
//  + éventuellement « APRÈS|redemarrer » ou « APRÈS|reconnecter »
// =====================================================================
import QtQuick
import QtQuick.Window

Window {
    id: win
    visible: true
    width: 860; height: 640
    minimumWidth: 620; minimumHeight: 460
    color: "#0b0d18"
    title: "Mises à jour CyberpunkOS"

    readonly property color jaune: "#f5e400"
    readonly property color cyan: "#00f0ff"
    readonly property color magenta: "#ff2bd6"
    readonly property string police: "Noto Sans"
    readonly property string policeData: "Noto Sans Mono"

    // ---- arguments
    readonly property var args: {
        var a = Qt.application.arguments, i = a.indexOf("--")
        return i >= 0 ? a.slice(i + 1) : []
    }
    readonly property string mode: args.length > 0 ? args[0] : "installee"
    readonly property string version: args.length > 1 ? args[1] : ""
    readonly property string actuelle: args.length > 2 ? args[2] : ""
    readonly property string fichier: args.length > 3 ? args[3] : "/usr/share/cyberpunkos/nouveautes.txt"
    readonly property bool dispo: mode === "dispo"

    // ---- lecture des nouveautés
    property var items: []
    property string apres: ""
    function couleur(t) {
        var u = t.toUpperCase()
        if (u.indexOf("NOUVEAU") === 0) return jaune
        if (u.indexOf("CORRIG") === 0) return magenta
        return cyan
    }
    function charger() {
        var x = new XMLHttpRequest()
        x.open("GET", "file://" + fichier, false)
        try { x.send(null) } catch (e) { return }
        var lignes = (x.responseText || "").split("\n"), l = []
        for (var i = 0; i < lignes.length; i++) {
            var s = lignes[i].trim()
            if (s === "" || s.charAt(0) === "#") continue
            var p = s.indexOf("|")
            var type = p > 0 ? s.substring(0, p).trim() : "NOUVEAU"
            var texte = p > 0 ? s.substring(p + 1).trim() : s
            var tu = type.toUpperCase()
            if (tu === "APRÈS" || tu === "APRES") {
                var a = texte.toLowerCase()
                apres = a.indexOf("red") === 0 ? "Redémarrage conseillé après l'installation"
                      : a.indexOf("rec") === 0 ? "Reconnexion conseillée après l'installation" : ""
                continue
            }
            l.push({ type: type, texte: texte, c: couleur(type) })
        }
        if (l.length === 0) l.push({ type: "INFO", texte: "Améliorations et corrections diverses.", c: cyan })
        items = l
    }
    Component.onCompleted: charger()

    function choisir(c) { console.warn("CYBERPUNKOS_CHOIX=" + c); Qt.quit() }

    // ---- fond quadrillé
    Item {
        anchors.fill: parent
        clip: true
        Repeater {
            model: Math.ceil(win.width / 60) + 1
            Rectangle { x: index * 60; width: 1; height: win.height; color: win.magenta; opacity: 0.06 }
        }
        Repeater {
            model: Math.ceil(win.height / 60) + 1
            Rectangle { y: index * 60; height: 1; width: win.width; color: win.magenta; opacity: 0.06 }
        }
    }

    // ---- en-tête
    Column {
        id: tete
        x: 36; y: 28
        width: win.width - 72
        spacing: 6
        Text {
            text: win.dispo ? "// QUOI DE NEUF ?" : "// INSTALLÉE ✓"
            color: win.magenta; font.family: win.policeData; font.pixelSize: 13; font.letterSpacing: 5
        }
        Text {
            text: "CyberpunkOS V." + win.version
            color: win.jaune; font.family: win.police; font.pixelSize: 34; font.bold: true
        }
        Text {
            text: win.dispo ? ("Tu as la V." + win.actuelle + " · nouvelle version disponible")
                            : "Installée sur ce PC"
            color: "#9aa0bd"; font.family: win.policeData; font.pixelSize: 14
        }
        Item { width: 1; height: 8 }
        Rectangle { width: 140; height: 3; color: win.jaune }
    }

    // ---- liste des nouveautés
    ListView {
        id: liste
        anchors.top: tete.bottom; anchors.topMargin: 22
        anchors.left: parent.left; anchors.leftMargin: 36
        anchors.right: parent.right; anchors.rightMargin: 36
        anchors.bottom: pied.top; anchors.bottomMargin: 18
        clip: true
        spacing: 10
        model: win.items
        delegate: Rectangle {
            width: liste.width
            height: Math.max(48, ligne.implicitHeight + 24)
            color: Qt.rgba(1, 1, 1, 0.03)
            Rectangle { width: 3; height: parent.height; color: modelData.c }
            Text {
                id: etiquette
                x: 18; anchors.verticalCenter: parent.verticalCenter
                width: 120
                text: modelData.type.toUpperCase()
                color: modelData.c; font.family: win.policeData; font.pixelSize: 12; font.letterSpacing: 3
                elide: Text.ElideRight
            }
            Text {
                id: ligne
                anchors.left: etiquette.right; anchors.leftMargin: 12
                anchors.right: parent.right; anchors.rightMargin: 16
                anchors.verticalCenter: parent.verticalCenter
                text: modelData.texte
                wrapMode: Text.WordWrap
                color: "#c8cbe0"; font.family: win.police; font.pixelSize: 15
            }
        }
    }

    // ---- pied : rappel + boutons
    Item {
        id: pied
        anchors.left: parent.left; anchors.leftMargin: 36
        anchors.right: parent.right; anchors.rightMargin: 36
        anchors.bottom: parent.bottom; anchors.bottomMargin: 26
        height: 52

        Column {
            anchors.verticalCenter: parent.verticalCenter
            spacing: 4
            Row {
                spacing: 8
                Rectangle {
                    width: 14; height: 14; color: "transparent"; border.color: win.cyan; border.width: 2
                    anchors.verticalCenter: parent.verticalCenter
                    Rectangle { anchors.fill: parent; anchors.margins: 3; color: win.cyan }
                }
                Text { text: "Tes choix perso (fond, couleurs) sont gardés"; color: "#9aa0bd"; font.family: win.police; font.pixelSize: 13 }
            }
            Text {
                visible: win.apres !== ""
                text: "⟳ " + win.apres
                color: win.magenta; font.family: win.police; font.pixelSize: 13
            }
        }

        Row {
            anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter
            spacing: 12
            Repeater {
                model: win.dispo ? [ { t: "Plus tard", c: "plustard", plein: false }, { t: "Installer maintenant", c: "installer", plein: true } ]
                                 : [ { t: "Fermer", c: "fermer", plein: true } ]
                Item {
                    width: lib.implicitWidth + 44; height: 44
                    Canvas {
                        anchors.fill: parent
                        property bool survol: zone.containsMouse
                        onSurvolChanged: requestPaint()
                        onPaint: {
                            var c = getContext("2d"); c.reset()
                            var k = 12, w = width, h = height
                            c.beginPath(); c.moveTo(k, 1); c.lineTo(w - 1, 1); c.lineTo(w - 1, h - k); c.lineTo(w - k, h - 1); c.lineTo(1, h - 1); c.lineTo(1, k); c.closePath()
                            if (modelData.plein) { c.fillStyle = survol ? "#fff36b" : win.jaune; c.fill() }
                            else { c.fillStyle = survol ? "rgba(0,240,255,0.15)" : "transparent"; c.fill(); c.lineWidth = 2; c.strokeStyle = win.cyan; c.stroke() }
                        }
                    }
                    Text {
                        id: lib; anchors.centerIn: parent; text: modelData.t
                        color: modelData.plein ? "#07080f" : win.cyan
                        font.family: win.police; font.pixelSize: 15; font.bold: true
                    }
                    MouseArea { id: zone; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: win.choisir(modelData.c) }
                }
            }
        }
    }
}
